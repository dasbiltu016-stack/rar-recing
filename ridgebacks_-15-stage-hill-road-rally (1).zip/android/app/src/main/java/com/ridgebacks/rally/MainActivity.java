package com.ridgebacks.rally;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
