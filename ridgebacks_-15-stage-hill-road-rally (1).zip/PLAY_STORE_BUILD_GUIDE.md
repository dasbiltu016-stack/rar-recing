# Ridgebacks Rally: Android App Bundle (.aab) Build Guide

আপনার গেমের ভেতরে অফিসিয়াল **Capacitor Android Native Project** সম্পূর্ণ রেডি করে দেওয়া হয়েছে।

---

## প্যাকেজ ও AdMob তথ্য:
- **Package Name (Application ID):** `com.ridgebacks.rally`
- **App Name:** `Ridgebacks Rally`
- **Live AdMob App ID:** `ca-app-pub-8022103414024000~7337020727`
- **Rewarded Video Unit (Fuel / Hull Refill):** `ca-app-pub-8022103414024000/5756199959`
- **Rewarded Interstitial Unit (Stage Complete):** `ca-app-pub-8022103414024000/6566864538`
- **Native Ad Unit:** `ca-app-pub-8022103414024000/5756199959`

---

## প্লে স্টোরে আপলোড করার জন্য `.aab` বানানোর উপায় (২ মিনিট):

### ধাপ ১: প্রজেক্টটি ডাউনলোড করুন
Google AI Studio-র উপরের ডানদিকের ডাউনলোড অপশন বা গিটহাবের মাধ্যমে আপনার সম্পূর্ণ কোডবেস ডাউনলোড করুন।

### ধাপ ২: Android Studio-তে ওপেন করুন
1. **Android Studio** সফটওয়্যারটি ওপেন করুন।
2. **Open**-এ ক্লিক করে আপনার ডাউনলোড করা ফোল্ডারের ভেতরের `android` ফোল্ডারটি সিলেক্ট করুন।
3. প্রোজেক্ট লোড হওয়া পর্যন্ত ১ মিনিট অপেক্ষা করুন (Gradle automatically sync হবে)।

### ধাপ ৩: `.aab` (Android App Bundle) এক্সপোর্ট করুন
1. Android Studio-র উপরের মেনু থেকে:  
   **Build** > **Generate Signed Bundle / APK...** ক্লিক করুন।
2. **Android App Bundle (.aab)** সিলেক্ট করে **Next** দিন।
3. আপনার Keystore সিলেক্ট করুন (না থাকলে **Create new...** দিয়ে নাম ও পাসওয়ার্ড দিন)।
4. **release** সিলেক্ট করে **Create / Finish** বাটনে চাপ দিন।

আপনার প্লে স্টোর রেডি `.aab` ফাইলটি `android/app/release/app-release.aab` ফোল্ডারে সেভ হয়ে যাবে!

---

## প্লে স্টোরে আপলোড:
1. আপনার [Google Play Console](https://play.google.com/console)-এ যান।
2. **Create app** > নাম দিন `Ridgebacks Rally`।
3. **Production** বা **Internal Testing** ট্যাবে গিয়ে তৈরি হওয়া `app-release.aab` ফাইলটি ড্র্যাগ করে আপলোড করে দিন।
