import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Pause,
  Play,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  Camera,
  Flag,
  ShieldAlert,
  Gauge,
  Compass,
  Trophy,
  ArrowRight,
} from 'lucide-react';
import { LEVELS } from './game/levels';
import { LIVERY_PRESETS } from './game/models';
import { rallyAudio } from './game/audio';
import {
  RallyCanvas,
  GamePhase,
  CameraMode,
  TelemetryData,
} from './components/RallyCanvas';

interface StageRecord {
  stars: number;
  bestTime: number;
}

const INITIAL_TELEMETRY: TelemetryData = {
  speedKmh: 0,
  rpm: 1400,
  gear: 1,
  progressPct: 0,
  distanceMeters: 0,
  totalMeters: 950,
  elapsedSeconds: 0,
  hullHealth: 100,
  fuel: 100,
  nitroCharge: 100,
  slopePercent: 0,
  gripPercent: 100,
  paceNote: 'CLEAR CREST AHEAD',
  paceSeverity: 'normal',
  hitFlash: false,
  driftActive: false,
};

const ADMOB_IDS = {
  appId: 'ca-app-pub-8022103414024000~7337020727',
  rewarded: 'ca-app-pub-8022103414024000/5756199959',
  rewardedInterstitial: 'ca-app-pub-8022103414024000/6566864538',
  native: 'ca-app-pub-8022103414024000/5756199959',
};

export default function App() {
  const [levelIndex, setLevelIndex] = useState<number>(0);
  const [gamePhase, setGamePhase] = useState<GamePhase>('title');
  const [cameraMode, setCameraMode] = useState<CameraMode>('chase');
  const [liveryHex, setLiveryHex] = useState<number>(LIVERY_PRESETS[0].hex);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [showStageGrid, setShowStageGrid] = useState<boolean>(false);
  const [resetCounter, setResetCounter] = useState<number>(0);
  const [refillCounter, setRefillCounter] = useState<number>(0);

  // Rewarded Test Ad state (Fuel / Hull refill)
  const [showRewardAd, setShowRewardAd] = useState<boolean>(false);
  const [adSecondsLeft, setAdSecondsLeft] = useState<number>(5);
  const [adRewardReady, setAdRewardReady] = useState<boolean>(false);
  const [rewardToast, setRewardToast] = useState<boolean>(false);

  // Rewarded Interstitial Ad state (level complete)
  const [showInterstitialAd, setShowInterstitialAd] = useState<boolean>(false);
  const [interstitialSecondsLeft, setInterstitialSecondsLeft] = useState<number>(4);
  const [interstitialReady, setInterstitialReady] = useState<boolean>(false);
  const [pendingVictoryStats, setPendingVictoryStats] = useState<{
    timeSeconds: number;
    hullRemaining: number;
    collisions: number;
    stars: number;
  } | null>(null);

  const [telemetry, setTelemetry] = useState<TelemetryData>(INITIAL_TELEMETRY);
  const [lastVictoryStats, setLastVictoryStats] = useState<{
    timeSeconds: number;
    hullRemaining: number;
    collisions: number;
    stars: number;
  } | null>(null);
  const [gameOverReason, setGameOverReason] = useState<string>('');

  const [stageRecords, setStageRecords] = useState<Record<number, StageRecord>>(
    () => {
      try {
        const saved = localStorage.getItem('ridgebacks_rally_records_v1');
        return saved ? JSON.parse(saved) : {};
      } catch {
        return {};
      }
    }
  );

  useEffect(() => {
    try {
      localStorage.setItem(
        'ridgebacks_rally_records_v1',
        JSON.stringify(stageRecords)
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [stageRecords]);

  // Countdown effect for the Rewarded Test Ad
  useEffect(() => {
    if (!showRewardAd) return;
    if (adSecondsLeft <= 0) {
      setAdRewardReady(true);
      return;
    }
    const timer = window.setTimeout(() => {
      setAdSecondsLeft((s) => s - 1);
    }, 1000);
    return () => clearTimeout(timer);
  }, [showRewardAd, adSecondsLeft]);

  // Countdown effect for the Rewarded Interstitial Test Ad (on level complete)
  useEffect(() => {
    if (!showInterstitialAd) return;
    if (interstitialSecondsLeft <= 0) {
      setInterstitialReady(true);
      return;
    }
    const timer = window.setTimeout(() => {
      setInterstitialSecondsLeft((s) => s - 1);
    }, 1000);
    return () => clearTimeout(timer);
  }, [showInterstitialAd, interstitialSecondsLeft]);

  const handleOpenRewardAd = useCallback(() => {
    // Pause simulation while watching the test ad
    setGamePhase((prev) => (prev === 'playing' ? 'paused' : prev));
    setAdSecondsLeft(5);
    setAdRewardReady(false);
    setShowRewardAd(true);
  }, []);

  const handleClaimAdReward = useCallback(() => {
    setShowRewardAd(false);
    setRefillCounter((c) => c + 1);
    setTelemetry((prev) => ({
      ...prev,
      fuel: 100,
      hullHealth: 100,
      nitroCharge: 100,
    }));
    setGamePhase('playing');
    setRewardToast(true);
    window.setTimeout(() => setRewardToast(false), 2600);
  }, []);

  const handleCloseInterstitialAd = useCallback(() => {
    setShowInterstitialAd(false);
    if (pendingVictoryStats) {
      setLastVictoryStats(pendingVictoryStats);
    }
    setGamePhase('victory');
  }, [pendingVictoryStats]);

  const touchInputRef = useRef({
    steer: 0,
    throttle: false,
    brake: false,
    handbrake: false,
    nitro: false,
  });

  const currentLevel = LEVELS[levelIndex] || LEVELS[0];

  const handleStartStage = useCallback((targetIdx?: number) => {
    rallyAudio.startEngineLoop();
    if (typeof targetIdx === 'number') {
      setLevelIndex(targetIdx);
    }
    setResetCounter((c) => c + 1);
    setGamePhase('playing');
    setShowStageGrid(false);
  }, []);

  const handleRestartStage = useCallback(() => {
    rallyAudio.startEngineLoop();
    setResetCounter((c) => c + 1);
    setGamePhase('playing');
  }, []);

  const handleNextStage = useCallback(() => {
    const nextIdx = Math.min(LEVELS.length - 1, levelIndex + 1);
    setLevelIndex(nextIdx);
    setResetCounter((c) => c + 1);
    setGamePhase('playing');
  }, [levelIndex]);

  const handleToggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      rallyAudio.setMuted(next);
      return next;
    });
  }, []);

  const handleCycleCamera = useCallback(() => {
    setCameraMode((prev) =>
      prev === 'chase' ? 'action' : prev === 'action' ? 'hood' : 'chase'
    );
  }, []);

  const handleTogglePause = useCallback(() => {
    setGamePhase((prev) =>
      prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev
    );
  }, []);

  const handleToggleDock = useCallback(() => {
    setDockCollapsed((prev) => !prev);
  }, []);

  const handleStageComplete = useCallback(
    (stats: {
      timeSeconds: number;
      hullRemaining: number;
      collisions: number;
      stars: number;
    }) => {
      setPendingVictoryStats(stats);
      setStageRecords((prev) => {
        const existing = prev[currentLevel.level];
        const bestStars = existing
          ? Math.max(existing.stars, stats.stars)
          : stats.stars;
        const bestTime = existing
          ? Math.min(existing.bestTime, stats.timeSeconds)
          : stats.timeSeconds;
        return {
          ...prev,
          [currentLevel.level]: { stars: bestStars, bestTime },
        };
      });
      // Show Rewarded Interstitial Ad when level is completed
      setInterstitialSecondsLeft(4);
      setInterstitialReady(false);
      setShowInterstitialAd(true);
    },
    [currentLevel.level]
  );

  const handleGameOver = useCallback((reason: string) => {
    setGameOverReason(reason);
    setGamePhase('gameover');
  }, []);

  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const rem = sec % 60;
    return `${String(mins).padStart(2, '0')}:${rem.toFixed(1).padStart(4, '0')}`;
  };

  const totalStarsEarned = Object.values(stageRecords).reduce(
    (acc, r) => acc + r.stars,
    0
  );

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#090d14] select-none">
      {/* 1. Isolated 3D WebGL Viewport Container */}
      <RallyCanvas
        levelIndex={levelIndex}
        gamePhase={gamePhase}
        cameraMode={cameraMode}
        liveryHex={liveryHex}
        resetCounter={resetCounter}
        refillCounter={refillCounter}
        touchInputRef={touchInputRef}
        onTelemetry={setTelemetry}
        onStageComplete={handleStageComplete}
        onGameOver={handleGameOver}
        onTogglePause={handleTogglePause}
        onStartFromKey={() => handleStartStage()}
        onCycleCamera={handleCycleCamera}
        onToggleDock={handleToggleDock}
      />

      {/* Screen-edge impact hit-flash vignette */}
      {gamePhase === 'playing' && telemetry.hitFlash && (
        <div
          className="pointer-events-none absolute inset-0 border-8 border-red-500/80 transition-opacity duration-150"
          aria-hidden="true"
        />
      )}

      {/* =====================================================================
          2. TITLE SCREEN (Full-Viewport Game Shell with 35%+ Negative Space)
         ===================================================================== */}
      {gamePhase === 'title' && (
        <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-6 md:p-10 bg-gradient-to-t from-[#090d14]/90 via-[#090d14]/35 to-[#090d14]/75">
          {/* Top Perimeter Status Strip */}
          <div className="flex items-center justify-between gap-4">
            <div className="text-xs font-medium tracking-wide text-slate-300 font-mono-num">
              <span>15 MOUNTAIN PASS STAGES</span>
              <span className="mx-2 text-slate-600">·</span>
              <span>CAMPAIGN STARS {totalStarsEarned} / 45</span>
              <span className="mx-2 text-slate-600">·</span>
              <span className="text-amber-400">
                STAGE {String(currentLevel.level).padStart(2, '0')}:{' '}
                {currentLevel.name.toUpperCase()}
              </span>
            </div>

            <div className="pointer-events-auto flex items-center gap-2">
              <button
                onClick={handleToggleMute}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-200 bg-[#0f172a]/95 border border-slate-800 rounded-lg hover:border-slate-600 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                <span>{isMuted ? 'Audio Muted' : 'Audio Active'}</span>
              </button>
            </div>
          </div>

          {/* Center-Left Hero Lockup & Stage Selector Modal */}
          {!showStageGrid ? (
            <div className="my-auto max-w-2xl">
              {/* Bespoke Inline SVG Title Lockup */}
              <div className="mb-3">
                <svg
                  viewBox="0 0 620 118"
                  className="w-full max-w-[540px] h-auto drop-shadow-[0_6px_24px_rgba(0,0,0,0.85)]"
                  role="img"
                  aria-label="Ridgebacks: 15-Stage Hill Road Rally"
                >
                  <defs>
                    <linearGradient id="ridgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#fbbf24" />
                      <stop offset="55%" stopColor="#f59e0b" />
                      <stop offset="100%" stopColor="#ea580c" />
                    </linearGradient>
                  </defs>
                  {/* Stylized Mountain Switchback Emblem */}
                  <path
                    d="M8 94 L56 22 L92 66 L124 30 L166 94 Z"
                    fill="none"
                    stroke="url(#ridgeGrad)"
                    strokeWidth="5"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M36 94 Q78 72 64 56 Q48 40 94 26"
                    fill="none"
                    stroke="#f8fafc"
                    strokeWidth="3.5"
                    strokeDasharray="6 5"
                  />
                  {/* Main Display Lockup */}
                  <text
                    x="184"
                    y="68"
                    fill="#f8fafc"
                    fontFamily="Oxanium, sans-serif"
                    fontWeight="800"
                    fontSize="60"
                    letterSpacing="3"
                  >
                    RIDGEBACKS
                  </text>
                  <text
                    x="186"
                    y="98"
                    fill="#fbbf24"
                    fontFamily="JetBrains Mono, monospace"
                    fontWeight="700"
                    fontSize="15"
                    letterSpacing="4.5"
                  >
                    15-STAGE HILL ROAD OBSTACLE RALLY
                  </text>
                </svg>
              </div>

              <p className="text-slate-300 text-sm md:text-base max-w-xl leading-relaxed mb-6">
                Conquer 15 treacherous switchback mountain stages. Thread narrow
                cliffside hairpins, counter-steer across gravel and black ice,
                and dodge rolling timber and live rockfalls before your chassis
                gives out.
              </p>

              {/* Selected Stage Summary Line (Unboxed Metadata with Separators) */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300 font-mono-num mb-6">
                <span className="text-amber-400 font-semibold">
                  Stage {String(currentLevel.level).padStart(2, '0')} / 15: {currentLevel.name}
                </span>
                <span aria-hidden="true">·</span>
                <span>{currentLevel.region}</span>
                <span aria-hidden="true">·</span>
                <span>Surface: {currentLevel.surfaceLabel}</span>
                <span aria-hidden="true">·</span>
                <span>{currentLevel.lengthMeters}m Distance</span>
                <span aria-hidden="true">·</span>
                <span>{currentLevel.obstacleCount} Hazards</span>
              </div>

              {/* AdMob Native Test Ad Banner */}
              <div className="pointer-events-auto my-4 p-3 rounded-xl bg-[#0f172a]/90 border border-slate-700/80 max-w-xl flex items-center justify-between gap-3 shadow-md">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
                    <Trophy className="w-5 h-5 text-amber-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.2 bg-amber-500/20 border border-amber-500/50 text-amber-300 text-[9px] font-bold font-mono rounded">
                        Ad · Native
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono truncate">
                        {ADMOB_IDS.native}
                      </span>
                    </div>
                    <div className="text-xs font-semibold text-slate-100 truncate mt-0.5">
                      Apex Performance Gear & Nitro Boosters
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      Upgrade suspension and rally tires for hazardous mountain switchbacks.
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleOpenRewardAd}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-transform active:scale-95 shrink-0 whitespace-nowrap cursor-pointer shadow"
                >
                  Install / View
                </button>
              </div>

              {/* Primary Start CTA & Stage Selection Toggle */}
              <div className="pointer-events-auto flex flex-wrap items-center gap-3.5">
                <button
                  onClick={() => handleStartStage()}
                  className="flex items-center gap-3 px-7 py-3.5 text-sm font-bold tracking-wider uppercase text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg shadow-lg transition-transform active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>
                    Start Stage {String(currentLevel.level).padStart(2, '0')}
                  </span>
                </button>

                <button
                  onClick={() => setShowStageGrid(true)}
                  className="flex items-center gap-2 px-5 py-3.5 text-sm font-semibold text-slate-100 bg-[#0f172a]/95 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Compass className="w-4 h-4 text-amber-400" />
                  <span>Select Stage (1–15)</span>
                </button>

                {/* Livery Quick Selector */}
                <div className="flex items-center gap-1.5 px-3 py-2 bg-[#0f172a]/95 border border-slate-800 rounded-lg">
                  <span className="text-xs text-slate-400 mr-1">Livery</span>
                  {LIVERY_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => setLiveryHex(preset.hex)}
                      className={`w-6 h-6 rounded-md border transition-transform cursor-pointer ${
                        liveryHex === preset.hex
                          ? 'border-white scale-110'
                          : 'border-slate-700 opacity-75 hover:opacity-100'
                      }`}
                      style={{
                        backgroundColor: `#${preset.hex.toString(16).padStart(6, '0')}`,
                      }}
                      title={preset.name}
                      aria-label={`Select ${preset.name} livery`}
                    />
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* 15-Stage Selection Grid Modal */
            <div className="pointer-events-auto my-auto w-full max-w-5xl bg-[#0b111d]/95 border border-slate-800 rounded-xl p-6 shadow-2xl">
              <div className="flex items-center justify-between gap-4 pb-4 mb-4 border-b border-slate-800">
                <div>
                  <h2 className="text-xl font-bold text-slate-100 font-display">
                    Select Mountain Pass Stage (01 – 15)
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Every stage increases switchback curvature, elevation grade,
                    and obstacle density. Click any stage to launch.
                  </p>
                </div>
                <button
                  onClick={() => setShowStageGrid(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Back to Title
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 max-h-[58vh] overflow-y-auto pr-1">
                {LEVELS.map((lvl, idx) => {
                  const rec = stageRecords[lvl.level];
                  const isSelected = idx === levelIndex;
                  return (
                    <button
                      key={lvl.level}
                      onClick={() => {
                        setLevelIndex(idx);
                        handleStartStage(idx);
                      }}
                      className={`text-left p-3 rounded-lg border transition-colors cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-500 text-slate-100'
                          : 'bg-[#111827]/90 border-slate-800/90 hover:border-slate-600 text-slate-200'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs font-mono-num text-amber-400 mb-1">
                          <span>STAGE {String(lvl.level).padStart(2, '0')}</span>
                          <span>
                            {rec ? '★'.repeat(rec.stars) + '☆'.repeat(3 - rec.stars) : '☆☆☆'}
                          </span>
                        </div>
                        <div className="font-semibold text-sm text-slate-100 truncate">
                          {lvl.name}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1">
                          {lvl.surfaceLabel} · {lvl.lengthMeters}m
                        </div>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono-num mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                        <span>{lvl.hairpinCount} Hairpins</span>
                        <span>{lvl.obstacleCount} Hazards</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Single Flat Control-Hint Line */}
          <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-800/70 text-xs text-slate-400 font-mono-num">
            <span>
              WASD / Arrows Drive & Steer · Space Handbrake Drift · Shift Nitro
              Boost · C Camera View · H Hide Dock · Esc Pause
            </span>
            <span className="text-slate-300">
              Press Enter or Space to Start Stage{' '}
              {String(currentLevel.level).padStart(2, '0')}
            </span>
          </div>
        </div>
      )}

      {/* =====================================================================
          3. PLAYING HUD (Ultra-Low-Occlusion Perimeter Layout for Mobile & Desktop)
         ===================================================================== */}
      {gamePhase !== 'title' && (
        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-2 sm:p-3 md:p-5">
          {/* Top Perimeter Strip: Compact Single-Row Status + Quick Actions */}
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between gap-1.5 bg-[#090d14]/85 border border-slate-800/90 rounded-lg px-2.5 py-1.5">
              {/* Left: Stage & Progress */}
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-xs font-bold text-amber-400 font-mono-num whitespace-nowrap shrink-0">
                  S{String(currentLevel.level).padStart(2, '0')}/15
                </span>
                <span className="hidden sm:inline text-xs text-slate-200 font-medium truncate max-w-[140px]">
                  {currentLevel.name}
                </span>
                <span className="text-[11px] text-slate-300 font-mono-num whitespace-nowrap shrink-0">
                  {telemetry.distanceMeters}m ({telemetry.progressPct}%)
                </span>
              </div>

              {/* Center: Speed, Fuel & Hull Readout */}
              <div className="flex items-center gap-2 text-xs font-mono-num whitespace-nowrap shrink-0">
                <span className="font-extrabold text-white text-sm">
                  {String(telemetry.speedKmh).padStart(3, '0')}{' '}
                  <span className="text-[10px] font-normal text-slate-400">
                    KM/H
                  </span>
                </span>
                <span className="text-slate-600">·</span>
                <span
                  className={`font-bold ${
                    telemetry.fuel > 50
                      ? 'text-amber-400'
                      : telemetry.fuel > 25
                        ? 'text-orange-400'
                        : 'text-red-400'
                  }`}
                >
                  FUEL {telemetry.fuel}%
                </span>
                <span className="text-slate-600">·</span>
                <span
                  className={`font-bold ${
                    telemetry.hullHealth > 55
                      ? 'text-emerald-400'
                      : telemetry.hullHealth > 25
                        ? 'text-amber-400'
                        : 'text-red-400'
                  }`}
                >
                  HULL {telemetry.hullHealth}%
                </span>
              </div>

              {/* Right: Quick Action Buttons (Camera, Retry, Stage Select, Pause) */}
              <div className="pointer-events-auto flex items-center gap-1 shrink-0">
                <select
                  aria-label="Select Stage"
                  value={levelIndex}
                  onChange={(e) => handleStartStage(Number(e.target.value))}
                  className="bg-slate-900 border border-slate-700 text-slate-100 text-[11px] rounded px-1.5 py-1 font-mono-num cursor-pointer focus:outline-none"
                >
                  {LEVELS.map((lvl, idx) => (
                    <option key={lvl.level} value={idx}>
                      S{String(lvl.level).padStart(2, '0')}
                    </option>
                  ))}
                </select>

                <button
                  onClick={handleCycleCamera}
                  className="p-1.5 text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded transition-colors cursor-pointer"
                  title="Switch Camera View"
                  aria-label="Switch Camera View"
                >
                  <Camera className="w-3.5 h-3.5 text-amber-400" />
                </button>

                <button
                  onClick={handleRestartStage}
                  className="p-1.5 text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded transition-colors cursor-pointer"
                  title="Restart Stage"
                  aria-label="Restart Stage"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-300" />
                </button>

                <button
                  onClick={handleToggleMute}
                  className="p-1.5 text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded transition-colors cursor-pointer"
                  title={isMuted ? 'Unmute' : 'Mute'}
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? (
                    <VolumeX className="w-3.5 h-3.5 text-red-400" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                  )}
                </button>

                <button
                  onClick={handleTogglePause}
                  className="p-1.5 text-slate-950 bg-amber-500 hover:bg-amber-400 rounded transition-colors cursor-pointer"
                  title="Pause Game"
                  aria-label="Pause Game"
                >
                  <Pause className="w-3.5 h-3.5 fill-current" />
                </button>
              </div>
            </div>

            {/* Second Slim Row: Co-Driver Pace Note + Interactive "Watch Ad -> Full Fuel/Hull" Button */}
            <div className="flex items-center justify-between gap-2 px-0.5">
              <div
                className={`px-2.5 py-1 rounded border text-[11px] font-bold tracking-wide uppercase font-mono-num flex items-center gap-1.5 min-w-0 ${
                  telemetry.paceSeverity === 'danger'
                    ? 'bg-red-950/85 border-red-500/70 text-red-200'
                    : telemetry.paceSeverity === 'caution'
                      ? 'bg-amber-950/85 border-amber-500/70 text-amber-200'
                      : 'bg-[#090d14]/75 border-slate-800 text-slate-300'
                }`}
              >
                <ShieldAlert className="w-3 h-3 shrink-0 text-amber-400" />
                <span className="truncate">{telemetry.paceNote}</span>
              </div>

              {/* Interactive Reward Test Ad Button to Refill Fuel & Hull to 100% */}
              <div className="pointer-events-auto flex items-center gap-1.5 shrink-0">
                <button
                  onClick={handleOpenRewardAd}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-[11px] font-mono-num shadow-md transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
                  title="Watch Reward Test Ad to Refill Fuel & Hull 100%"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>+AD FULL FUEL / HULL</span>
                </button>
              </div>
            </div>

            {/* Reward Claimed Confirmation Banner */}
            {rewardToast && (
              <div className="mx-auto px-4 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs font-mono-num shadow-lg">
                REWARD GRANTED: FUEL & HULL 100% FULL!
              </div>
            )}
          </div>

          {/* Bottom Controls Area: Corner Thumb Pads on Mobile + Collapsible Dock on Desktop */}
          <div className="w-full flex flex-col items-center">
            {/* Mobile / Touchscreen Corner Pedals (Leaves center 100% clear for the car!) */}
            <div className="pointer-events-auto md:hidden w-full flex items-end justify-between gap-2 pb-1 px-0.5">
              {/* Left Thumb: Steer Left & Right */}
              <div className="flex items-center gap-1.5">
                <button
                  onPointerDown={() => {
                    touchInputRef.current.steer = -1;
                  }}
                  onPointerUp={() => {
                    touchInputRef.current.steer = 0;
                  }}
                  onPointerCancel={() => {
                    touchInputRef.current.steer = 0;
                  }}
                  onPointerLeave={() => {
                    touchInputRef.current.steer = 0;
                  }}
                  className="w-13 h-12 rounded-xl bg-[#090d14]/75 border border-slate-600/80 text-white font-bold text-base active:bg-amber-500 active:text-slate-950 active:border-amber-400 select-none"
                  aria-label="Steer Left"
                >
                  ◀
                </button>
                <button
                  onPointerDown={() => {
                    touchInputRef.current.steer = 1;
                  }}
                  onPointerUp={() => {
                    touchInputRef.current.steer = 0;
                  }}
                  onPointerCancel={() => {
                    touchInputRef.current.steer = 0;
                  }}
                  onPointerLeave={() => {
                    touchInputRef.current.steer = 0;
                  }}
                  className="w-13 h-12 rounded-xl bg-[#090d14]/75 border border-slate-600/80 text-white font-bold text-base active:bg-amber-500 active:text-slate-950 active:border-amber-400 select-none"
                  aria-label="Steer Right"
                >
                  ▶
                </button>
              </div>

              {/* Right Thumb: Drift, Brake & Gas Pedals */}
              <div className="flex items-center gap-1.5">
                <button
                  onPointerDown={() => {
                    touchInputRef.current.handbrake = true;
                  }}
                  onPointerUp={() => {
                    touchInputRef.current.handbrake = false;
                  }}
                  onPointerCancel={() => {
                    touchInputRef.current.handbrake = false;
                  }}
                  onPointerLeave={() => {
                    touchInputRef.current.handbrake = false;
                  }}
                  className="px-2.5 h-12 rounded-xl bg-[#090d14]/75 border border-amber-500/60 text-amber-300 font-bold text-[11px] uppercase active:bg-amber-500 active:text-slate-950 select-none"
                >
                  Drift
                </button>
                <button
                  onPointerDown={() => {
                    touchInputRef.current.brake = true;
                  }}
                  onPointerUp={() => {
                    touchInputRef.current.brake = false;
                  }}
                  onPointerCancel={() => {
                    touchInputRef.current.brake = false;
                  }}
                  onPointerLeave={() => {
                    touchInputRef.current.brake = false;
                  }}
                  className="px-3 h-12 rounded-xl bg-[#090d14]/75 border border-red-500/60 text-red-300 font-bold text-[11px] uppercase active:bg-red-500 active:text-white select-none"
                >
                  Brake
                </button>
                <button
                  onPointerDown={() => {
                    rallyAudio.startEngineLoop();
                    touchInputRef.current.throttle = true;
                  }}
                  onPointerUp={() => {
                    touchInputRef.current.throttle = false;
                  }}
                  onPointerCancel={() => {
                    touchInputRef.current.throttle = false;
                  }}
                  onPointerLeave={() => {
                    touchInputRef.current.throttle = false;
                  }}
                  className="px-4 h-12 rounded-xl bg-amber-500/90 border border-amber-300 text-slate-950 font-extrabold text-xs uppercase active:bg-amber-400 select-none shadow-lg"
                >
                  Gas
                </button>
              </div>
            </div>

            {/* Desktop Collapsible Bottom Control Dock (Hidden on small mobile screens so car is never blocked) */}
            <div className="pointer-events-auto hidden md:flex mx-auto w-full max-w-[900px] flex-col items-center">
              <button
                onClick={handleToggleDock}
                className="flex items-center gap-1.5 px-3.5 py-1 text-[11px] font-medium text-slate-300 bg-[#090d14]/95 border border-b-0 border-slate-800 rounded-t-lg hover:text-white transition-colors cursor-pointer"
              >
                {dockCollapsed ? (
                  <>
                    <ChevronUp className="w-3.5 h-3.5 text-amber-400" />
                    <span>Show Telemetry & Controls [H]</span>
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                    <span>Hide Controls [H]</span>
                  </>
                )}
              </button>

              {!dockCollapsed && (
                <div className="w-full bg-[#090d14]/95 border border-slate-800 rounded-xl px-4 py-2.5 flex items-center justify-between gap-4 shadow-2xl">
                  <div className="flex items-center gap-4">
                    <div className="flex items-baseline gap-1.5 min-w-[100px]">
                      <span className="text-2xl font-extrabold font-display text-slate-100 font-mono-num">
                        {String(telemetry.speedKmh).padStart(3, '0')}
                      </span>
                      <span className="text-xs font-semibold text-slate-400">
                        KM/H
                      </span>
                    </div>

                    <div className="flex flex-col min-w-[110px]">
                      <div className="flex items-center justify-between text-xs font-mono-num">
                        <span className="text-amber-400 font-bold">FUEL</span>
                        <span className="text-slate-300">
                          {telemetry.fuel}%
                        </span>
                      </div>
                      <div className="mt-1 w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-400 transition-all duration-100"
                          style={{ width: `${telemetry.fuel}%` }}
                        />
                      </div>
                    </div>

                    <div className="flex flex-col min-w-[100px]">
                      <div className="flex items-center justify-between text-xs font-mono-num">
                        <span className="text-cyan-400 font-semibold">
                          NITRO
                        </span>
                        <span className="text-slate-300">
                          {telemetry.nitroCharge}%
                        </span>
                      </div>
                      <div className="mt-1 w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-cyan-400 transition-all duration-100"
                          style={{ width: `${telemetry.nitroCharge}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleOpenRewardAd}
                    className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Watch AdMob Ad (Full Fuel & Hull)</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          4. PAUSE / VICTORY / GAME OVER MODALS + REWARD TEST AD MODAL
         ===================================================================== */}
      {gamePhase === 'paused' && !showRewardAd && (
        <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-[#090d14]/85 p-4">
          <div className="w-full max-w-md bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-2xl">
            <h2 className="text-2xl font-bold text-slate-100 font-display">
              Stage Paused
            </h2>
            <p className="text-xs text-slate-400 mt-1 font-mono-num">
              Stage {String(currentLevel.level).padStart(2, '0')} / 15 ·{' '}
              {currentLevel.name} · {currentLevel.surfaceLabel}
            </p>

            <div className="my-5 space-y-2 text-xs text-slate-300 border-y border-slate-800 py-4 font-mono-num">
              <div className="flex justify-between">
                <span className="text-slate-400">Progress</span>
                <span>
                  {telemetry.distanceMeters}m / {telemetry.totalMeters}m (
                  {telemetry.progressPct}%)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Fuel Tank</span>
                <span className="text-amber-400 font-bold">
                  {telemetry.fuel}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Chassis Hull Integrity</span>
                <span className="text-emerald-400 font-bold">
                  {telemetry.hullHealth}%
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                onClick={handleOpenRewardAd}
                className="w-full py-2.5 text-sm font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Watch AdMob Ad → Full Fuel & Hull (100%)</span>
              </button>
              <button
                onClick={handleTogglePause}
                className="w-full py-2.5 text-sm font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg transition-colors cursor-pointer"
              >
                Resume Stage
              </button>
              <button
                onClick={handleRestartStage}
                className="w-full py-2.5 text-sm font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Restart Stage
              </button>
              <button
                onClick={() => setGamePhase('title')}
                className="w-full py-2.5 text-sm font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              >
                Return to Title Screen
              </button>
            </div>
          </div>
        </div>
      )}

      {gamePhase === 'victory' && lastVictoryStats && (
        <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-[#090d14]/88 p-4">
          <div className="w-full max-w-md bg-[#0f172a] border border-slate-800 rounded-xl p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono-num font-bold text-amber-400 uppercase tracking-wider">
                Stage {String(currentLevel.level).padStart(2, '0')} Cleared
              </span>
              <span className="text-lg text-amber-400 font-mono-num">
                {'★'.repeat(lastVictoryStats.stars)}
                {'☆'.repeat(3 - lastVictoryStats.stars)}
              </span>
            </div>

            <h2 className="text-2xl font-bold text-slate-100 font-display mt-1">
              {currentLevel.level === 15
                ? 'Summit Crown Conquered!'
                : `${currentLevel.name} Complete`}
            </h2>

            <div className="my-5 space-y-2.5 text-xs border-y border-slate-800 py-4 font-mono-num">
              <div className="flex justify-between">
                <span className="text-slate-400">Stage Finish Time</span>
                <span className="text-slate-100 font-bold">
                  {formatTime(lastVictoryStats.timeSeconds)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Target Par Time</span>
                <span className="text-slate-300">
                  {formatTime(currentLevel.parTimeSeconds)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hull Integrity Remaining</span>
                <span className="text-emerald-400 font-bold">
                  {lastVictoryStats.hullRemaining}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hazard Impacts</span>
                <span className="text-slate-200">
                  {lastVictoryStats.collisions}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              {levelIndex < LEVELS.length - 1 ? (
                <button
                  onClick={handleNextStage}
                  className="w-full py-3 text-sm font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span>
                    Continue to Stage {String(currentLevel.level + 1).padStart(2, '0')}:{' '}
                    {LEVELS[levelIndex + 1].name}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <div className="p-3 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-200 text-xs text-center mb-1">
                  All 15 Mountain Pass Stages Completed! Total Campaign Stars:{' '}
                  {totalStarsEarned} / 45
                </div>
              )}

              <button
                onClick={handleRestartStage}
                className="w-full py-2.5 text-sm font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Replay Stage {String(currentLevel.level).padStart(2, '0')}
              </button>
              <button
                onClick={() => setGamePhase('title')}
                className="w-full py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              >
                Return to Title Screen
              </button>
            </div>
          </div>
        </div>
      )}

      {gamePhase === 'gameover' && !showRewardAd && (
        <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-[#090d14]/88 p-4">
          <div className="w-full max-w-md bg-[#0f172a] border border-red-900/60 rounded-xl p-6 shadow-2xl">
            <div className="text-xs font-mono-num font-bold text-red-400 uppercase tracking-wider">
              Stage {String(currentLevel.level).padStart(2, '0')} · Vehicle
              Stopped
            </div>
            <h2 className="text-2xl font-bold text-slate-100 font-display mt-1">
              Fuel / Hull Depleted
            </h2>
            <p className="text-xs text-slate-300 mt-1.5">{gameOverReason}</p>

            <div className="my-5 space-y-2 text-xs border-y border-slate-800 py-4 font-mono-num">
              <div className="flex justify-between">
                <span className="text-slate-400">Distance Reached</span>
                <span className="text-slate-100">
                  {telemetry.distanceMeters}m / {telemetry.totalMeters}m (
                  {telemetry.progressPct}%)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Fuel / Hull Status</span>
                <span className="text-red-400">
                  Fuel {telemetry.fuel}% · Hull {telemetry.hullHealth}%
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2.5">
              <button
                onClick={handleOpenRewardAd}
                className="w-full py-3 text-sm font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Watch AdMob Ad → Full Fuel & Hull & Continue</span>
              </button>
              <button
                onClick={handleRestartStage}
                className="w-full py-2.5 text-sm font-bold text-slate-950 bg-amber-500 hover:bg-amber-400 rounded-lg transition-colors cursor-pointer"
              >
                Restart Stage {String(currentLevel.level).padStart(2, '0')}
              </button>
              <button
                onClick={() => setGamePhase('title')}
                className="w-full py-2.5 text-sm font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
              >
                Select Another Stage
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          5. REWARDED VIDEO TEST AD OVERLAY MODAL (Fuel & Hull Refill)
         ===================================================================== */}
      {showRewardAd && (
        <div className="pointer-events-auto absolute inset-0 z-50 flex items-center justify-center bg-black/95 p-4">
          <div className="w-full max-w-md bg-[#0b111d] border-2 border-amber-500/80 rounded-2xl overflow-hidden shadow-2xl">
            {/* Top Ad Header Bar */}
            <div className="bg-slate-900 px-4 py-2.5 flex items-center justify-between border-b border-slate-800 text-xs font-mono-num">
              <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-bold">
                ADMOB · REWARDED
              </span>
              <span className="text-slate-300 font-semibold">
                {adRewardReady
                  ? 'Reward Unlocked!'
                  : `Reward in ${adSecondsLeft}s`}
              </span>
            </div>

            {/* Video Ad Stage */}
            <div className="p-5 text-center bg-gradient-to-b from-[#111a2e] via-[#0d1627] to-[#0b111d]">
              {/* Simulated Commercial Video Screen */}
              <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-700/80 mb-3 shadow-inner flex flex-col justify-between p-3">
                <div className="flex items-center justify-between text-[10px] font-mono-num z-10">
                  <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-bold uppercase tracking-wider">
                    Sponsored Commercial
                  </span>
                  <span className="px-2 py-0.5 rounded bg-black/60 text-amber-300 font-semibold border border-amber-500/30">
                    Unit: {ADMOB_IDS.rewarded.slice(0, 22)}...
                  </span>
                </div>

                {/* Animated Commercial Visual */}
                <div className="my-auto py-2">
                  <div className="inline-flex p-3 rounded-2xl bg-amber-500/20 border border-amber-400/40 animate-pulse mb-2">
                    <Gauge className="w-8 h-8 text-amber-400" />
                  </div>
                  <h4 className="text-lg font-black text-white tracking-wide uppercase font-display">
                    Apex Nitro Rally Fuels
                  </h4>
                  <p className="text-[11px] text-amber-200/90 font-medium">
                    Maximum Octane Formula for Mountain Drifts & Hill Climbing
                  </p>
                </div>

                <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 z-10 border-t border-slate-800/80 pt-1.5">
                  <span className="text-emerald-400 font-semibold">● AdMob Unit Active</span>
                  <span>Audio On · High Def</span>
                </div>
              </div>

              <div className="text-[10px] font-mono-num text-amber-400 uppercase tracking-widest">
                AdMob Rewarded Unit (Live ID)
              </div>
              <div className="text-[11px] font-mono text-slate-300 font-bold mb-1 truncate bg-slate-900/80 py-1 px-2 rounded border border-slate-800">
                {ADMOB_IDS.rewarded}
              </div>

              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Watch this sponsored advertisement to instantly unlock{' '}
                <strong className="text-emerald-400">100% Full Fuel</strong>,{' '}
                <strong className="text-emerald-400">100% Chassis Hull</strong>,
                and <strong className="text-cyan-400">100% Nitro Boost</strong>.
              </p>

              {/* Progress Bar */}
              <div className="mt-4 w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-700"
                  style={{
                    width: `${((5 - adSecondsLeft) / 5) * 100}%`,
                  }}
                />
              </div>
              <div className="mt-2 text-xs font-mono-num text-slate-400 flex items-center justify-between px-1">
                <span>{adRewardReady ? '✓ Reward Ready' : `Playing Ad: ${5 - adSecondsLeft}/5s`}</span>
                <span className="text-emerald-400 font-bold">{adRewardReady ? 'Unlocked' : `${adSecondsLeft}s remaining`}</span>
              </div>
            </div>

            {/* Footer Action Buttons */}
            <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex flex-col gap-2">
              <button
                disabled={!adRewardReady}
                onClick={handleClaimAdReward}
                className={`w-full py-3 rounded-xl font-bold text-sm transition-all ${
                  adRewardReady
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer shadow-lg'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {adRewardReady
                  ? '✓ Claim Reward: Full Fuel & Hull (100%)'
                  : `Please Wait ${adSecondsLeft}s to Unlock Full Refill...`}
              </button>

              {!adRewardReady && (
                <button
                  onClick={() => {
                    setShowRewardAd(false);
                    setGamePhase('playing');
                  }}
                  className="w-full py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Close Ad (Skip Reward)
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          6. REWARDED INTERSTITIAL TEST AD OVERLAY (Level Complete)
         ===================================================================== */}
      {showInterstitialAd && (
        <div className="pointer-events-auto absolute inset-0 z-50 flex items-center justify-center bg-black/95 p-4">
          <div className="w-full max-w-md bg-[#0b111d] border-2 border-cyan-500/80 rounded-2xl overflow-hidden shadow-2xl">
            {/* Top Ad Header Bar */}
            <div className="bg-slate-900 px-4 py-2.5 flex items-center justify-between border-b border-slate-800 text-xs font-mono-num">
              <span className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-bold">
                ADMOB · INTERSTITIAL
              </span>
              <span className="text-slate-300 font-semibold">
                {interstitialReady
                  ? 'Skip / Continue Ready'
                  : `Ad ends in ${interstitialSecondsLeft}s`}
              </span>
            </div>

            {/* Interstitial Ad Stage */}
            <div className="p-5 text-center bg-gradient-to-b from-[#0f2338] via-[#0c1c2c] to-[#0b111d]">
              {/* Commercial Video Screen */}
              <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-700/80 mb-3 shadow-inner flex flex-col justify-between p-3">
                <div className="flex items-center justify-between text-[10px] font-mono-num z-10">
                  <span className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-bold uppercase tracking-wider">
                    Sponsored Interstitial
                  </span>
                  <span className="px-2 py-0.5 rounded bg-black/60 text-cyan-300 font-semibold border border-cyan-500/30">
                    Unit: {ADMOB_IDS.rewardedInterstitial.slice(0, 22)}...
                  </span>
                </div>

                <div className="my-auto py-2">
                  <div className="inline-flex p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 animate-pulse mb-2">
                    <Flag className="w-8 h-8 text-cyan-400" />
                  </div>
                  <h4 className="text-lg font-black text-white tracking-wide uppercase font-display">
                    Ridgebacks Championship Tires
                  </h4>
                  <p className="text-[11px] text-cyan-200/90 font-medium">
                    Engineered with Grip-Matrix Compound for Wet Mud & Mountain Ice
                  </p>
                </div>

                <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 z-10 border-t border-slate-800/80 pt-1.5">
                  <span className="text-cyan-400 font-semibold">● AdMob Live Interstitial</span>
                  <span>Audio On · High Def</span>
                </div>
              </div>

              <div className="text-[10px] font-mono-num text-cyan-400 uppercase tracking-widest">
                AdMob Interstitial Unit (Live ID)
              </div>
              <div className="text-[11px] font-mono text-slate-300 font-bold mb-1 truncate bg-slate-900/80 py-1 px-2 rounded border border-slate-800">
                {ADMOB_IDS.rewardedInterstitial}
              </div>

              <h3 className="text-lg font-bold text-white font-display mt-2">
                Stage {String(currentLevel.level).padStart(2, '0')} Conquered!
              </h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Great run across <strong className="text-white">{currentLevel.name}</strong>. Enjoy this sponsored pitstop break before reviewing your stage results.
              </p>

              {/* Progress Bar */}
              <div className="mt-4 w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-500 transition-all duration-700"
                  style={{
                    width: `${((4 - interstitialSecondsLeft) / 4) * 100}%`,
                  }}
                />
              </div>
              <div className="mt-2 text-xs font-mono-num text-slate-400 flex items-center justify-between px-1">
                <span>{interstitialReady ? '✓ Ready to Proceed' : `Playing Ad: ${4 - interstitialSecondsLeft}/4s`}</span>
                <span className="text-cyan-400 font-bold">{interstitialReady ? 'Complete' : `${interstitialSecondsLeft}s remaining`}</span>
              </div>
            </div>

            {/* Footer Action Buttons */}
            <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex flex-col gap-2">
              <button
                disabled={!interstitialReady}
                onClick={handleCloseInterstitialAd}
                className={`w-full py-3 rounded-xl font-bold text-sm transition-all ${
                  interstitialReady
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer shadow-lg'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {interstitialReady
                  ? 'Continue to Stage Summary →'
                  : `Closing in ${interstitialSecondsLeft}s...`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
