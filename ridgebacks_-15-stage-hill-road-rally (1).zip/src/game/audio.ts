class RallyAudioEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;

  private skidGain: GainNode | null = null;
  private skidFilter: BiquadFilterNode | null = null;
  private isRunning: boolean = false;

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.ctx && this.engineGain && this.skidGain) {
      const now = this.ctx.currentTime;
      if (muted) {
        this.engineGain.gain.setTargetAtTime(0, now, 0.04);
        this.skidGain.gain.setTargetAtTime(0, now, 0.04);
      }
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public startEngineLoop() {
    const ctx = this.ensureContext();
    if (!ctx || this.isRunning) return;

    try {
      // Primary rally boxer engine oscillator
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'triangle';
      osc1.frequency.value = 58;
      osc2.frequency.value = 29;

      filter.type = 'lowpass';
      filter.frequency.value = 260;
      filter.Q.value = 3.2;

      gain.gain.value = 0.001;

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();

      this.engineOsc1 = osc1;
      this.engineOsc2 = osc2;
      this.engineFilter = filter;
      this.engineGain = gain;

      // Procedural white noise buffer for tire skid / gravel slip
      const bufferSize = ctx.sampleRate * 1.5;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const noiseNode = ctx.createBufferSource();
      noiseNode.buffer = noiseBuffer;
      noiseNode.loop = true;

      const sFilter = ctx.createBiquadFilter();
      sFilter.type = 'bandpass';
      sFilter.frequency.value = 1150;
      sFilter.Q.value = 2.4;

      const sGain = ctx.createGain();
      sGain.gain.value = 0;

      noiseNode.connect(sFilter);
      sFilter.connect(sGain);
      sGain.connect(ctx.destination);
      noiseNode.start();

      this.skidFilter = sFilter;
      this.skidGain = sGain;
      this.isRunning = true;
    } catch {
      // Ignore audio errors on restricted autoplay
    }
  }

  public updateTelemetry(
    speedRatio: number,
    throttle: number,
    driftIntensity: number,
    isBoosting: boolean,
    active: boolean
  ) {
    if (!this.ctx || !this.isRunning || !this.engineOsc1 || !this.engineOsc2 || !this.engineGain || !this.engineFilter || !this.skidGain || !this.skidFilter) {
      return;
    }

    const now = this.ctx.currentTime;
    if (this.isMuted || !active) {
      this.engineGain.gain.setTargetAtTime(0, now, 0.06);
      this.skidGain.gain.setTargetAtTime(0, now, 0.05);
      return;
    }

    // Simulate 5-gear rally transmission RPM curve
    const clampedSpeed = Math.max(0, Math.min(1.25, speedRatio));
    const gearSaw = (clampedSpeed * 4.2) % 1;
    const baseFreq = 46 + clampedSpeed * 95 + gearSaw * 42 + (isBoosting ? 35 : 0);

    this.engineOsc1.frequency.setTargetAtTime(baseFreq, now, 0.04);
    this.engineOsc2.frequency.setTargetAtTime(baseFreq * 0.505, now, 0.04);

    const filterFreq = 220 + clampedSpeed * 980 + throttle * 360 + (isBoosting ? 500 : 0);
    this.engineFilter.frequency.setTargetAtTime(filterFreq, now, 0.05);

    const targetGain = 0.032 + throttle * 0.032 + clampedSpeed * 0.025;
    this.engineGain.gain.setTargetAtTime(targetGain, now, 0.05);

    // Tire screech / gravel slide
    const slip = Math.max(0, Math.min(1, driftIntensity));
    const targetSkidGain = slip > 0.15 ? (slip - 0.15) * 0.085 : 0;
    this.skidGain.gain.setTargetAtTime(targetSkidGain, now, 0.04);
    this.skidFilter.frequency.setTargetAtTime(900 + slip * 750, now, 0.05);
  }

  public playImpact(severity: number = 1.0) {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(135 * Math.max(0.6, severity), now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.24);

    gain.gain.setValueAtTime(Math.min(0.26, 0.16 * severity), now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.27);
  }

  public playBoostBurst() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(520, now + 0.18);

    gain.gain.setValueAtTime(0.09, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.21);
  }

  public playCheckpoint() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const notes = [587.33, 880]; // D5 -> A5
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.07);
      gain.gain.setValueAtTime(0.08, now + idx * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.22);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.07);
      osc.stop(now + idx * 0.07 + 0.24);
    });
  }

  public playVictoryFanfare() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880]; // A major arpeggio
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);
      gain.gain.setValueAtTime(0.11, now + idx * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.09 + 0.38);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.4);
    });
  }

  public playGameOverTone() {
    if (this.isMuted) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const notes = [330, 293.66, 246.94, 196];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + idx * 0.11);
      gain.gain.setValueAtTime(0.08, now + idx * 0.11);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.11 + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.11);
      osc.stop(now + idx * 0.11 + 0.32);
    });
  }
}

export const rallyAudio = new RallyAudioEngine();
