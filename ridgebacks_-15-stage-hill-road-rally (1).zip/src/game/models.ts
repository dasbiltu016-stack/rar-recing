import * as THREE from 'three';
import { LevelConfig, ObstacleInstance, createSeededRandom } from './levels';

export interface CarRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  paintMaterials: THREE.MeshPhysicalMaterial[];
  wheelFrontLeftPivot: THREE.Group;
  wheelFrontRightPivot: THREE.Group;
  wheels: THREE.Object3D[];
  brakeLights: THREE.MeshStandardMaterial;
  nitroFlames: THREE.Mesh[];
  headlightCones: THREE.Mesh[];
}

export interface DynamicObstacleNode {
  data: ObstacleInstance;
  group: THREE.Group;
  mesh: THREE.Object3D;
  telegraphRing?: THREE.Mesh;
  basePos: THREE.Vector3;
  tangent: THREE.Vector3;
  right: THREE.Vector3;
  normal: THREE.Vector3;
  hitCooldown: number;
}

export interface BuiltTrack {
  curve: THREE.CatmullRomCurve3;
  trackGroup: THREE.Group;
  obstacles: DynamicObstacleNode[];
  dispose: () => void;
}

export const LIVERY_PRESETS = [
  { id: 'amber', name: 'Rally Amber', hex: 0xf59e0b, accent: 0x111827 },
  { id: 'cyan', name: 'Alpine Cyan', hex: 0x06b6d4, accent: 0x0f172a },
  { id: 'crimson', name: 'Corsa Red', hex: 0xef4444, accent: 0x18181b },
  { id: 'titanium', name: 'Titanium Silver', hex: 0xe2e8f0, accent: 0x0f172a },
] as const;

export function createRoadTexture(
  renderer: THREE.WebGLRenderer,
  cfg: LevelConfig
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base road tint
  const baseColor = new THREE.Color(cfg.roadTint);
  ctx.fillStyle = `#${baseColor.getHexString()}`;
  ctx.fillRect(0, 0, 512, 512);

  // Procedural asphalt / gravel grain
  const rand = createSeededRandom(cfg.level * 131);
  for (let i = 0; i < 6500; i++) {
    const x = Math.floor(rand() * 512);
    const y = Math.floor(rand() * 512);
    const v = Math.floor((rand() - 0.5) * 32);
    ctx.fillStyle =
      v > 0 ? `rgba(255,255,255,${v / 255})` : `rgba(0,0,0,${-v / 255})`;
    ctx.fillRect(x, y, 2, 2);
  }

  // Red & white rally rumble curbs on outer edges (u = 0..0.08 and 0.92..1.0)
  const curbWidth = 34;
  const stripeLen = 64;
  for (let y = 0; y < 512; y += stripeLen) {
    const isRed = (y / stripeLen) % 2 === 0;
    ctx.fillStyle = isRed ? '#ef4444' : '#ffffff';
    ctx.fillRect(0, y, curbWidth, stripeLen);
    ctx.fillRect(512 - curbWidth, y, curbWidth, stripeLen);
  }

  // Crisp bright white shoulder lines
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(curbWidth + 8, 0, 10, 512);
  ctx.fillRect(512 - curbWidth - 18, 0, 10, 512);

  // High-visibility dual dashed yellow mountain pass center line
  ctx.fillStyle = '#facc15';
  for (let y = 20; y < 512; y += 128) {
    ctx.fillRect(244, y, 10, 76);
    ctx.fillRect(258, y, 10, 76);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, Math.round(cfg.lengthMeters / 12));
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return tex;
}

export function createChevronTexture(
  renderer: THREE.WebGLRenderer
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(0, 0, 256, 128);

  ctx.fillStyle = '#0f172a';
  for (let x = -128; x < 384; x += 48) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 24, 0);
    ctx.lineTo(x + 88, 128);
    ctx.lineTo(x + 64, 128);
    ctx.closePath();
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return tex;
}

export function createCheckeredTexture(
  renderer: THREE.WebGLRenderer
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d')!;

  const sq = 16;
  for (let y = 0; y < 64; y += sq) {
    for (let x = 0; x < 256; x += sq) {
      const even = ((x / sq) + (y / sq)) % 2 === 0;
      ctx.fillStyle = even ? '#f8fafc' : '#0f172a';
      ctx.fillRect(x, y, sq, sq);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return tex;
}

export function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 8, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0,0,0,0.85)');
  grad.addColorStop(0.6, 'rgba(0,0,0,0.4)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  return tex;
}

/**
 * Builds the 11-part composite 3D Rally Car (`THREE.Group`) with bottom-center pivot
 * and varied roughness/metalness across parts.
 */
export function createRallyCarModel(
  initialLiveryHex: number = 0xf59e0b
): CarRig {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const paintMat = new THREE.MeshPhysicalMaterial({
    color: initialLiveryHex,
    metalness: 0.65,
    roughness: 0.22,
    clearcoat: 0.85,
    clearcoatRoughness: 0.15,
  });

  const carbonMat = new THREE.MeshStandardMaterial({
    color: 0x14171f,
    metalness: 0.25,
    roughness: 0.72,
  });

  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x090d16,
    metalness: 0.9,
    roughness: 0.08,
    clearcoat: 1.0,
  });

  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.92,
    roughness: 0.18,
  });

  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x111318,
    metalness: 0.08,
    roughness: 0.88,
  });

  const brakeLightMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0x991b1b,
    emissiveIntensity: 0.8,
    roughness: 0.3,
  });

  const headlightMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xfef08a,
    emissiveIntensity: 2.2,
    roughness: 0.15,
  });

  // 1. Contact shadow grounding plane
  const shadowTex = createContactShadowTexture();
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(3.1, 5.2),
    new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.65,
    })
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = 0.03;
  root.add(shadowPlane);

  // 2. Lower chassis pan & rear diffuser
  const chassisMesh = new THREE.Mesh(
    new THREE.BoxGeometry(2.04, 0.28, 4.35),
    carbonMat
  );
  chassisMesh.position.set(0, 0.34, 0);
  chassisMesh.castShadow = true;
  chassisMesh.receiveShadow = true;
  bodyGroup.add(chassisMesh);

  // 3. Sculpted main body hull (ExtrudeGeometry side profile)
  const bodyShape = new THREE.Shape();
  bodyShape.moveTo(-2.15, 0.35);
  bodyShape.lineTo(2.15, 0.35);
  bodyShape.lineTo(2.05, 0.78);
  bodyShape.lineTo(1.15, 0.88);
  bodyShape.lineTo(0.45, 1.32);
  bodyShape.lineTo(-1.15, 1.32);
  bodyShape.lineTo(-1.82, 0.92);
  bodyShape.lineTo(-2.15, 0.78);
  bodyShape.closePath();

  const extrudeSettings: THREE.ExtrudeGeometryOptions = {
    steps: 1,
    depth: 1.76,
    bevelEnabled: true,
    bevelThickness: 0.1,
    bevelSize: 0.08,
    bevelSegments: 3,
  };
  const hullGeo = new THREE.ExtrudeGeometry(bodyShape, extrudeSettings);
  hullGeo.center();
  // Rotate so length is along Z and width is along X
  hullGeo.rotateY(Math.PI / 2);
  const hullMesh = new THREE.Mesh(hullGeo, paintMat);
  hullMesh.position.set(0, 0.82, 0);
  hullMesh.castShadow = true;
  hullMesh.receiveShadow = true;
  bodyGroup.add(hullMesh);

  // 4. Widebody rally fender flares (front & rear)
  const fenderGeo = new THREE.BoxGeometry(2.22, 0.32, 0.95);
  const frontFenders = new THREE.Mesh(fenderGeo, paintMat);
  frontFenders.position.set(0, 0.56, -1.28);
  const rearFenders = new THREE.Mesh(fenderGeo, paintMat);
  rearFenders.position.set(0, 0.58, 1.25);
  bodyGroup.add(frontFenders, rearFenders);

  // 5. Cabin tinted greenhouse windows
  const cabinGeo = new THREE.BoxGeometry(1.56, 0.44, 1.85);
  const cabinMesh = new THREE.Mesh(cabinGeo, glassMat);
  cabinMesh.position.set(0, 1.12, 0.12);
  bodyGroup.add(cabinMesh);

  // 6. Roof air intake scoop + quad rally light pod
  const scoopMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.52, 0.14, 0.65),
    carbonMat
  );
  scoopMesh.position.set(0, 1.39, -0.15);
  bodyGroup.add(scoopMesh);

  const podBar = new THREE.Mesh(
    new THREE.BoxGeometry(1.1, 0.1, 0.18),
    carbonMat
  );
  podBar.position.set(0, 1.37, -0.68);
  bodyGroup.add(podBar);

  // 7. High-downforce rear rally wing spoiler + endplates
  const wingGroup = new THREE.Group();
  const wingBlade = new THREE.Mesh(
    new THREE.BoxGeometry(1.96, 0.07, 0.38),
    carbonMat
  );
  wingBlade.position.set(0, 1.36, 1.92);
  wingBlade.rotation.x = 0.18;
  wingGroup.add(wingBlade);

  const strutGeo = new THREE.BoxGeometry(0.08, 0.38, 0.24);
  const leftStrut = new THREE.Mesh(strutGeo, carbonMat);
  leftStrut.position.set(-0.62, 1.16, 1.88);
  const rightStrut = new THREE.Mesh(strutGeo, carbonMat);
  rightStrut.position.set(0.62, 1.16, 1.88);

  const plateGeo = new THREE.BoxGeometry(0.05, 0.26, 0.46);
  const leftPlate = new THREE.Mesh(plateGeo, paintMat);
  leftPlate.position.set(-0.98, 1.34, 1.92);
  const rightPlate = new THREE.Mesh(plateGeo, paintMat);
  rightPlate.position.set(0.98, 1.34, 1.92);

  wingGroup.add(leftStrut, rightStrut, leftPlate, rightPlate);
  bodyGroup.add(wingGroup);

  // 8. Front splitter, bull-bar & quad rally fog lamps
  const splitter = new THREE.Mesh(
    new THREE.BoxGeometry(2.08, 0.08, 0.42),
    carbonMat
  );
  splitter.position.set(0, 0.26, -2.08);
  bodyGroup.add(splitter);

  const headlightCones: THREE.Mesh[] = [];
  const coneGeo = new THREE.ConeGeometry(1.8, 14, 16, 1, true);
  coneGeo.rotateX(Math.PI / 2);
  coneGeo.translate(0, 0, -7);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xfef08a,
    transparent: true,
    opacity: 0.09,
    depthWrite: false,
    side: THREE.DoubleSide,
  });

  [-0.64, -0.28, 0.28, 0.64].forEach((xOffset, idx) => {
    const lamp = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.11, 0.12, 12),
      headlightMat
    );
    lamp.rotation.x = Math.PI / 2;
    lamp.position.set(xOffset, 0.64, -2.16);
    bodyGroup.add(lamp);

    if (idx === 0 || idx === 3) {
      const cone = new THREE.Mesh(coneGeo, coneMat);
      cone.position.set(xOffset, 0.6, -2.2);
      cone.rotation.x = -0.05;
      bodyGroup.add(cone);
      headlightCones.push(cone);
    }
  });

  // 9. Rear LED tail light bar & dual exhaust pipes with Nitro flames
  const tailBar = new THREE.Mesh(
    new THREE.BoxGeometry(1.76, 0.14, 0.1),
    brakeLightMat
  );
  tailBar.position.set(0, 0.78, 2.14);
  bodyGroup.add(tailBar);

  const nitroFlames: THREE.Mesh[] = [];
  const flameGeo = new THREE.ConeGeometry(0.12, 0.85, 10);
  flameGeo.rotateX(Math.PI / 2);
  const flameMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.85,
  });

  [-0.52, 0.52].forEach((xPos) => {
    const pipe = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.08, 0.3, 12),
      chromeMat
    );
    pipe.rotation.x = Math.PI / 2;
    pipe.position.set(xPos, 0.32, 2.18);
    bodyGroup.add(pipe);

    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(xPos, 0.32, 2.65);
    flame.visible = false;
    bodyGroup.add(flame);
    nitroFlames.push(flame);
  });

  // 10. Four multi-part wheels (tire + rim + spokes)
  const wheels: THREE.Object3D[] = [];
  const wheelFrontLeftPivot = new THREE.Group();
  const wheelFrontRightPivot = new THREE.Group();
  wheelFrontLeftPivot.position.set(-1.04, 0.42, -1.32);
  wheelFrontRightPivot.position.set(1.04, 0.42, -1.32);
  root.add(wheelFrontLeftPivot, wheelFrontRightPivot);

  const createWheelAssembly = () => {
    const wGroup = new THREE.Group();
    const tire = new THREE.Mesh(
      new THREE.CylinderGeometry(0.42, 0.42, 0.36, 20),
      tireMat
    );
    tire.rotation.z = Math.PI / 2;
    tire.castShadow = true;
    wGroup.add(tire);

    const rim = new THREE.Mesh(
      new THREE.CylinderGeometry(0.27, 0.27, 0.38, 12),
      chromeMat
    );
    rim.rotation.z = Math.PI / 2;
    wGroup.add(rim);

    const spokeBar = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.07, 0.48),
      carbonMat
    );
    wGroup.add(spokeBar);

    return wGroup;
  };

  const wFL = createWheelAssembly();
  const wFR = createWheelAssembly();
  wheelFrontLeftPivot.add(wFL);
  wheelFrontRightPivot.add(wFR);

  const wRL = createWheelAssembly();
  wRL.position.set(-1.04, 0.42, 1.28);
  const wRR = createWheelAssembly();
  wRR.position.set(1.04, 0.42, 1.28);
  root.add(wRL, wRR);

  wheels.push(wFL, wFR, wRL, wRR);

  return {
    root,
    bodyGroup,
    paintMaterials: [paintMat],
    wheelFrontLeftPivot,
    wheelFrontRightPivot,
    wheels,
    brakeLights: brakeLightMat,
    nitroFlames,
    headlightCones,
  };
}

/**
 * Generates the 3D winding hill road spline ("aka baka rasta"), extruded road surface,
 * inner mountain cliff wall, outer canyon drop, instanced pine trees & rocks,
 * and interactive 3D obstacle nodes ("samne badha").
 */
export function buildHillRoadTrack(
  renderer: THREE.WebGLRenderer,
  cfg: LevelConfig,
  obstacleDefs: ObstacleInstance[]
): BuiltTrack {
  const trackGroup = new THREE.Group();
  const disposableGeometries: THREE.BufferGeometry[] = [];
  const disposableMaterials: THREE.Material[] = [];
  const disposableTextures: THREE.Texture[] = [];

  // 1. Construct 3D winding switchback spline (CatmullRomCurve3)
  const rand = createSeededRandom(cfg.level * 7919 + 17);
  const controlCount = 70;
  const controlPoints: THREE.Vector3[] = [];
  let currentX = 0;
  let currentZ = 0;

  for (let i = 0; i <= controlCount; i++) {
    const u = i / controlCount;
    // Ease in curvature after start and before finish
    const envelope = Math.sin(Math.PI * u);
    const switchbackWave =
      Math.sin(u * Math.PI * cfg.curveFrequency) * cfg.curveAmplitude +
      Math.cos(u * Math.PI * (cfg.curveFrequency * 1.85 + 1.2)) *
        (cfg.curveAmplitude * 0.48) +
      Math.sin(u * Math.PI * (cfg.hairpinCount * 2.1)) *
        (cfg.curveAmplitude * 0.34);

    const x = switchbackWave * Math.pow(envelope, 0.65);

    // Elevation profile: continuous hill climb + steep crests and valleys
    const climbY =
      u * cfg.elevationGain +
      Math.sin(u * Math.PI * cfg.hillFrequency) *
        (cfg.elevationGain * 0.24) *
        envelope +
      Math.cos(u * Math.PI * (cfg.hillFrequency * 2.1)) *
        (cfg.elevationGain * 0.11) *
        envelope;

    currentX = x;
    currentZ = -u * cfg.lengthMeters;
    controlPoints.push(new THREE.Vector3(currentX, climbY, currentZ));
  }

  const curve = new THREE.CatmullRomCurve3(controlPoints, false, 'catmullrom', 0.5);

  // 2. Build unified ribbon mesh for road surface, cliffside rock wall, and canyon embankment
  const segments = Math.min(900, Math.max(420, Math.floor(cfg.lengthMeters / 2.6)));
  const halfWidth = cfg.roadWidth * 0.5;
  const cliffWidth = 13.5;
  const cliffHeight = 15.0;
  const dropWidth = 18.0;
  const dropDepth = 26.0;

  const roadPositions: number[] = [];
  const roadUVs: number[] = [];
  const roadIndices: number[] = [];

  const terrainPositions: number[] = [];
  const terrainColors: number[] = [];
  const terrainIndices: number[] = [];

  const upVec = new THREE.Vector3(0, 1, 0);
  const pt = new THREE.Vector3();
  const tangent = new THREE.Vector3();
  const right = new THREE.Vector3();

  const cCliff = new THREE.Color(cfg.rockColor);
  const cTerrain = new THREE.Color(cfg.terrainColor);
  const cShoulder = new THREE.Color(cfg.roadTint).multiplyScalar(0.8);

  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    curve.getPointAt(t, pt);
    curve.getTangentAt(t, tangent).normalize();
    right.crossVectors(tangent, upVec).normalize();

    // Road left and right vertices (slightly raised +0.04 on Y to prevent Z-fighting)
    const rLeft = pt.clone().addScaledVector(right, -halfWidth);
    const rRight = pt.clone().addScaledVector(right, halfWidth);
    rLeft.y += 0.04;
    rRight.y += 0.04;

    roadPositions.push(rLeft.x, rLeft.y, rLeft.z, rRight.x, rRight.y, rRight.z);
    roadUVs.push(0, t, 1, t);

    if (i < segments) {
      const base = i * 2;
      roadIndices.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }

    // Terrain cross-section (6 vertices per slice):
    // 0: Far outer cliff wall top (left)
    // 1: Inner cliff wall base (left road shoulder)
    // 2: Left under-road bed
    // 3: Right road shoulder
    // 4: Steep canyon slope mid
    // 5: Deep valley floor
    const noiseH = Math.sin(i * 0.37) * 2.2 + Math.cos(i * 0.83) * 1.4;
    const v0 = pt
      .clone()
      .addScaledVector(right, -(halfWidth + cliffWidth))
      .add(new THREE.Vector3(0, cliffHeight + noiseH, 0));
    const v1 = pt
      .clone()
      .addScaledVector(right, -(halfWidth + 0.9))
      .add(new THREE.Vector3(0, -0.05, 0));
    const v2 = pt
      .clone()
      .addScaledVector(right, 0)
      .add(new THREE.Vector3(0, -0.15, 0));
    const v3 = pt
      .clone()
      .addScaledVector(right, halfWidth + 0.9)
      .add(new THREE.Vector3(0, -0.05, 0));
    const v4 = pt
      .clone()
      .addScaledVector(right, halfWidth + dropWidth * 0.45)
      .add(new THREE.Vector3(0, -dropDepth * 0.45 + noiseH * 0.5, 0));
    const v5 = pt
      .clone()
      .addScaledVector(right, halfWidth + dropWidth)
      .add(new THREE.Vector3(0, -dropDepth, 0));

    const sliceVerts = [v0, v1, v2, v3, v4, v5];
    const sliceCols = [cCliff, cTerrain, cShoulder, cShoulder, cTerrain, cCliff];

    for (let k = 0; k < 6; k++) {
      terrainPositions.push(sliceVerts[k].x, sliceVerts[k].y, sliceVerts[k].z);
      const jitter = 0.92 + ((i * 17 + k * 31) % 15) * 0.01;
      terrainColors.push(
        sliceCols[k].r * jitter,
        sliceCols[k].g * jitter,
        sliceCols[k].b * jitter
      );
    }

    if (i < segments) {
      const rowA = i * 6;
      const rowB = (i + 1) * 6;
      for (let k = 0; k < 5; k++) {
        terrainIndices.push(
          rowA + k,
          rowA + k + 1,
          rowB + k,
          rowA + k + 1,
          rowB + k + 1,
          rowB + k
        );
      }
    }
  }

  const roadGeo = new THREE.BufferGeometry();
  roadGeo.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(roadPositions, 3)
  );
  roadGeo.setAttribute('uv', new THREE.Float32BufferAttribute(roadUVs, 2));
  roadGeo.setIndex(roadIndices);
  roadGeo.computeVertexNormals();
  disposableGeometries.push(roadGeo);

  const roadTex = createRoadTexture(renderer, cfg);
  disposableTextures.push(roadTex);

  const roadMat = new THREE.MeshStandardMaterial({
    map: roadTex,
    roughness: cfg.surface === 'ice' || cfg.surface === 'wet_asphalt' ? 0.28 : 0.78,
    metalness: cfg.surface === 'ice' ? 0.35 : 0.08,
  });
  disposableMaterials.push(roadMat);

  const roadMesh = new THREE.Mesh(roadGeo, roadMat);
  roadMesh.receiveShadow = true;
  trackGroup.add(roadMesh);

  const terrainGeo = new THREE.BufferGeometry();
  terrainGeo.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(terrainPositions, 3)
  );
  terrainGeo.setAttribute(
    'color',
    new THREE.Float32BufferAttribute(terrainColors, 3)
  );
  terrainGeo.setIndex(terrainIndices);
  terrainGeo.computeVertexNormals();
  disposableGeometries.push(terrainGeo);

  const terrainMat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.9,
    metalness: 0.05,
    flatShading: true,
  });
  disposableMaterials.push(terrainMat);

  const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
  terrainMesh.receiveShadow = true;
  trackGroup.add(terrainMesh);

  // 3. Instanced roadside Pine Trees, Cliff Boulders, and Guardrail Posts
  const treeCount = 140;
  const trunkGeo = new THREE.CylinderGeometry(0.18, 0.28, 1.6, 7);
  trunkGeo.translate(0, 0.8, 0);
  const foliageGeo = new THREE.ConeGeometry(1.35, 4.2, 7);
  foliageGeo.translate(0, 3.1, 0);
  disposableGeometries.push(trunkGeo, foliageGeo);

  const trunkMat = new THREE.MeshStandardMaterial({
    color: 0x452c1e,
    roughness: 0.9,
  });
  const foliageMat = new THREE.MeshStandardMaterial({
    color: cfg.surface === 'ice' ? 0x64748b : 0x1e3f29,
    roughness: 0.75,
  });
  disposableMaterials.push(trunkMat, foliageMat);

  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
  const foliageInst = new THREE.InstancedMesh(foliageGeo, foliageMat, treeCount);

  const dummy = new THREE.Object3D();
  const tintColor = new THREE.Color();

  for (let i = 0; i < treeCount; i++) {
    const t = 0.02 + (i / treeCount) * 0.96;
    curve.getPointAt(t, pt);
    curve.getTangentAt(t, tangent).normalize();
    right.crossVectors(tangent, upVec).normalize();

    const isLeft = i % 2 === 0;
    const dist = halfWidth + 1.8 + rand() * 5.2;
    const pos = pt.clone().addScaledVector(right, isLeft ? -dist : dist * 0.85);
    pos.y += isLeft ? (dist - halfWidth) * 0.55 : -(dist - halfWidth) * 0.65;

    const scale = 0.85 + rand() * 0.45;
    dummy.position.copy(pos);
    dummy.rotation.set(0, rand() * Math.PI * 2, 0);
    dummy.scale.setScalar(scale);
    dummy.updateMatrix();

    trunkInst.setMatrixAt(i, dummy.matrix);
    foliageInst.setMatrixAt(i, dummy.matrix);

    const shade = 0.85 + rand() * 0.3;
    tintColor.setHex(cfg.surface === 'ice' ? 0x94a3b8 : 0x22543d).multiplyScalar(shade);
    foliageInst.setColorAt(i, tintColor);
  }
  trunkInst.instanceMatrix.needsUpdate = true;
  foliageInst.instanceMatrix.needsUpdate = true;
  if (foliageInst.instanceColor) foliageInst.instanceColor.needsUpdate = true;
  trunkInst.computeBoundingSphere();
  foliageInst.computeBoundingSphere();
  trackGroup.add(trunkInst, foliageInst);

  // Guardrail posts along the dangerous right-hand canyon edge
  const postCount = Math.floor(110 * cfg.guardrailDensity) + 20;
  const postGeo = new THREE.BoxGeometry(0.24, 0.95, 0.24);
  postGeo.translate(0, 0.475, 0);
  const postMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    metalness: 0.5,
    roughness: 0.4,
  });
  disposableGeometries.push(postGeo);
  disposableMaterials.push(postMat);

  const postInst = new THREE.InstancedMesh(postGeo, postMat, postCount);
  for (let i = 0; i < postCount; i++) {
    const t = 0.02 + (i / postCount) * 0.96;
    curve.getPointAt(t, pt);
    curve.getTangentAt(t, tangent).normalize();
    right.crossVectors(tangent, upVec).normalize();

    const pos = pt.clone().addScaledVector(right, halfWidth + 0.32);
    dummy.position.copy(pos);
    dummy.rotation.set(0, Math.atan2(tangent.x, tangent.z), 0);
    dummy.scale.setScalar(1);
    dummy.updateMatrix();
    postInst.setMatrixAt(i, dummy.matrix);
  }
  postInst.instanceMatrix.needsUpdate = true;
  postInst.computeBoundingSphere();
  trackGroup.add(postInst);

  // 4. Finish Line Archway at t = 0.985
  const finishGroup = new THREE.Group();
  const finishT = 0.985;
  const finishPt = curve.getPointAt(finishT);
  const finishTan = curve.getTangentAt(finishT).normalize();
  finishGroup.position.copy(finishPt);
  finishGroup.rotation.y = Math.atan2(-finishTan.x, -finishTan.z);

  const pillarGeo = new THREE.BoxGeometry(0.55, 5.8, 0.55);
  pillarGeo.translate(0, 2.9, 0);
  const pillarMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.35,
    metalness: 0.4,
  });
  const leftPillar = new THREE.Mesh(pillarGeo, pillarMat);
  leftPillar.position.x = -halfWidth - 0.2;
  const rightPillar = new THREE.Mesh(pillarGeo, pillarMat);
  rightPillar.position.x = halfWidth + 0.2;

  const checkTex = createCheckeredTexture(renderer);
  const bannerGeo = new THREE.BoxGeometry(cfg.roadWidth + 1.2, 1.25, 0.35);
  const bannerMat = new THREE.MeshStandardMaterial({
    map: checkTex,
    roughness: 0.4,
  });
  const bannerMesh = new THREE.Mesh(bannerGeo, bannerMat);
  bannerMesh.position.y = 5.2;

  disposableGeometries.push(pillarGeo, bannerGeo);
  disposableMaterials.push(pillarMat, bannerMat);
  disposableTextures.push(checkTex);

  finishGroup.add(leftPillar, rightPillar, bannerMesh);
  trackGroup.add(finishGroup);

  // 5. Build 3D Obstacles ("samne badha") along the road
  const chevronTex = createChevronTexture(renderer);
  disposableTextures.push(chevronTex);

  const rockGeo = new THREE.DodecahedronGeometry(1.0, 1);
  const barrierGeo = new THREE.BoxGeometry(2.6, 1.15, 0.65);
  barrierGeo.translate(0, 0.575, 0);
  const logGeo = new THREE.CylinderGeometry(0.45, 0.45, 3.2, 12);
  logGeo.rotateZ(Math.PI / 2);
  const slickGeo = new THREE.CircleGeometry(1.9, 20);
  slickGeo.rotateX(-Math.PI / 2);
  const ringGeo = new THREE.RingGeometry(1.1, 1.45, 24);
  ringGeo.rotateX(-Math.PI / 2);

  disposableGeometries.push(rockGeo, barrierGeo, logGeo, slickGeo, ringGeo);

  const boulderMat = new THREE.MeshStandardMaterial({
    color: cfg.rockColor,
    roughness: 0.85,
    metalness: 0.1,
    flatShading: true,
  });
  const barrierMat = new THREE.MeshStandardMaterial({
    map: chevronTex,
    roughness: 0.4,
    metalness: 0.2,
  });
  const logMat = new THREE.MeshStandardMaterial({
    color: 0x5c3a21,
    roughness: 0.88,
  });
  const slickMat = new THREE.MeshStandardMaterial({
    color: 0x090d16,
    roughness: 0.06,
    metalness: 0.85,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const telegraphMat = new THREE.MeshBasicMaterial({
    color: 0xef4444,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.75,
    depthWrite: false,
  });

  disposableMaterials.push(
    boulderMat,
    barrierMat,
    logMat,
    slickMat,
    telegraphMat
  );

  const obstacles: DynamicObstacleNode[] = [];

  for (const obs of obstacleDefs) {
    const oPt = curve.getPointAt(obs.t);
    const oTan = curve.getTangentAt(obs.t).normalize();
    const oRight = new THREE.Vector3().crossVectors(oTan, upVec).normalize();
    const oNormal = new THREE.Vector3().crossVectors(oRight, oTan).normalize();

    const lateralMeters = obs.lateralRatio * (halfWidth - 1.35);
    const basePos = oPt.clone().addScaledVector(oRight, lateralMeters);

    const group = new THREE.Group();
    group.position.copy(basePos);
    group.rotation.y = Math.atan2(-oTan.x, -oTan.z);

    let mesh: THREE.Object3D;
    let telegraphRing: THREE.Mesh | undefined;

    if (obs.type === 'boulder' || obs.type === 'rockfall') {
      const m = new THREE.Mesh(rockGeo, boulderMat);
      m.scale.setScalar(obs.radius);
      m.position.y = obs.radius * 0.78;
      m.castShadow = true;
      mesh = m;
      group.add(m);

      if (obs.type === 'rockfall') {
        telegraphRing = new THREE.Mesh(ringGeo, telegraphMat);
        telegraphRing.position.y = 0.08;
        group.add(telegraphRing);
      }
    } else if (obs.type === 'barrier') {
      const m = new THREE.Mesh(barrierGeo, barrierMat);
      m.castShadow = true;
      mesh = m;
      group.add(m);
    } else if (obs.type === 'rolling_log') {
      const m = new THREE.Mesh(logGeo, logMat);
      m.position.y = 0.46;
      m.castShadow = true;
      mesh = m;
      group.add(m);

      telegraphRing = new THREE.Mesh(ringGeo, telegraphMat);
      telegraphRing.position.y = 0.08;
      group.add(telegraphRing);
    } else if (obs.type === 'narrow_gate') {
      // Twin rock pillars flanking a narrow central gap
      const gateContainer = new THREE.Group();
      const leftRock = new THREE.Mesh(rockGeo, boulderMat);
      leftRock.scale.set(1.4, 2.3, 1.4);
      leftRock.position.set(-2.6, 1.8, 0);
      const rightRock = new THREE.Mesh(rockGeo, boulderMat);
      rightRock.scale.set(1.4, 2.3, 1.4);
      rightRock.position.set(2.6, 1.8, 0);
      gateContainer.add(leftRock, rightRock);
      mesh = gateContainer;
      group.add(gateContainer);
    } else {
      // oil_slick
      const m = new THREE.Mesh(slickGeo, slickMat);
      m.position.y = 0.06;
      mesh = m;
      group.add(m);
    }

    trackGroup.add(group);
    obstacles.push({
      data: obs,
      group,
      mesh,
      telegraphRing,
      basePos,
      tangent: oTan,
      right: oRight,
      normal: oNormal,
      hitCooldown: 0,
    });
  }

  return {
    curve,
    trackGroup,
    obstacles,
    dispose: () => {
      disposableGeometries.forEach((g) => g.dispose());
      disposableMaterials.forEach((m) => m.dispose());
      disposableTextures.forEach((t) => t.dispose());
    },
  };
}
