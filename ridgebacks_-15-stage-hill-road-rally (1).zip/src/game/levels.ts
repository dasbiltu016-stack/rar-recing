export type SurfaceType = 'asphalt' | 'gravel' | 'mud' | 'ice' | 'wet_asphalt';

export type ObstacleType =
  | 'boulder'
  | 'barrier'
  | 'rolling_log'
  | 'oil_slick'
  | 'narrow_gate'
  | 'rockfall';

export interface ObstacleInstance {
  id: number;
  type: ObstacleType;
  /** Normalized progress along the track (0.04 to 0.96) */
  t: number;
  /** Lateral offset from road center (-1 to +1 of halfWidth) */
  lateralRatio: number;
  /** Width/radius in meters */
  radius: number;
  /** Dynamic movement speed (for rolling_log or rockfall) */
  speed: number;
  /** Phase offset for dynamic oscillation */
  phase: number;
}

export interface LevelConfig {
  level: number;
  name: string;
  subtitle: string;
  region: string;
  surface: SurfaceType;
  surfaceLabel: string;
  gripMultiplier: number;
  lengthMeters: number;
  roadWidth: number;
  curveAmplitude: number;
  curveFrequency: number;
  hairpinCount: number;
  elevationGain: number;
  hillFrequency: number;
  obstacleCount: number;
  dynamicHazardRatio: number;
  parTimeSeconds: number;
  skyTopColor: number;
  skyHorizonColor: number;
  terrainColor: number;
  rockColor: number;
  roadTint: number;
  sunIntensity: number;
  guardrailDensity: number;
}

export const LEVELS: LevelConfig[] = [
  {
    level: 1,
    name: 'Pinecrest Foothills',
    subtitle: 'Winding valley ascent with scattered rockfalls',
    region: 'Lower Ridge · 680m',
    surface: 'asphalt',
    surfaceLabel: 'Dry Tarmac',
    gripMultiplier: 1.0,
    lengthMeters: 950,
    roadWidth: 11.4,
    curveAmplitude: 28,
    curveFrequency: 3.5,
    hairpinCount: 2,
    elevationGain: 28,
    hillFrequency: 3.0,
    obstacleCount: 16,
    dynamicHazardRatio: 0.15,
    parTimeSeconds: 48,
    skyTopColor: 0x0f243c,
    skyHorizonColor: 0x2e5678,
    terrainColor: 0x1e3324,
    rockColor: 0x4b5563,
    roadTint: 0x262930,
    sunIntensity: 2.2,
    guardrailDensity: 0.85,
  },
  {
    level: 2,
    name: 'Serpentine Gorge',
    subtitle: 'Tight S-bends along the canyon rim with work barriers',
    region: 'Canyon Sector · 920m',
    surface: 'asphalt',
    surfaceLabel: 'Canyon Asphalt',
    gripMultiplier: 0.96,
    lengthMeters: 1100,
    roadWidth: 10.8,
    curveAmplitude: 38,
    curveFrequency: 4.5,
    hairpinCount: 3,
    elevationGain: 36,
    hillFrequency: 4.0,
    obstacleCount: 22,
    dynamicHazardRatio: 0.22,
    parTimeSeconds: 54,
    skyTopColor: 0x162944,
    skyHorizonColor: 0x486b8a,
    terrainColor: 0x263928,
    rockColor: 0x57534e,
    roadTint: 0x282b30,
    sunIntensity: 2.1,
    guardrailDensity: 0.8,
  },
  {
    level: 3,
    name: 'Timberline Switchbacks',
    subtitle: 'Steep logging road with rolling timber and loose gravel',
    region: 'Highland Forest · 1,180m',
    surface: 'gravel',
    surfaceLabel: 'Loose Gravel',
    gripMultiplier: 0.88,
    lengthMeters: 1250,
    roadWidth: 10.4,
    curveAmplitude: 46,
    curveFrequency: 5.2,
    hairpinCount: 4,
    elevationGain: 45,
    hillFrequency: 4.5,
    obstacleCount: 27,
    dynamicHazardRatio: 0.3,
    parTimeSeconds: 60,
    skyTopColor: 0x1b2434,
    skyHorizonColor: 0x5c5346,
    terrainColor: 0x2d3622,
    rockColor: 0x5c5449,
    roadTint: 0x3b332b,
    sunIntensity: 1.95,
    guardrailDensity: 0.72,
  },
  {
    level: 4,
    name: 'Redstone Hairpins',
    subtitle: 'Blind crests and double-apex cliff turns with rock slides',
    region: 'Red Escarpment · 1,420m',
    surface: 'gravel',
    surfaceLabel: 'Red Clay Gravel',
    gripMultiplier: 0.85,
    lengthMeters: 1380,
    roadWidth: 10.0,
    curveAmplitude: 54,
    curveFrequency: 6.0,
    hairpinCount: 5,
    elevationGain: 54,
    hillFrequency: 5.2,
    obstacleCount: 32,
    dynamicHazardRatio: 0.35,
    parTimeSeconds: 66,
    skyTopColor: 0x241726,
    skyHorizonColor: 0x804638,
    terrainColor: 0x4a2c22,
    rockColor: 0x6e4235,
    roadTint: 0x3d2924,
    sunIntensity: 2.0,
    guardrailDensity: 0.65,
  },
  {
    level: 5,
    name: 'Mistveil Viaduct',
    subtitle: 'Damp mountain tarmac with oil slicks and narrow stone gates',
    region: 'Cloud Pass · 1,690m',
    surface: 'wet_asphalt',
    surfaceLabel: 'Wet Tarmac',
    gripMultiplier: 0.82,
    lengthMeters: 1500,
    roadWidth: 9.6,
    curveAmplitude: 60,
    curveFrequency: 6.8,
    hairpinCount: 6,
    elevationGain: 60,
    hillFrequency: 5.8,
    obstacleCount: 36,
    dynamicHazardRatio: 0.38,
    parTimeSeconds: 72,
    skyTopColor: 0x111927,
    skyHorizonColor: 0x334155,
    terrainColor: 0x1e2923,
    rockColor: 0x475569,
    roadTint: 0x1e2229,
    sunIntensity: 1.5,
    guardrailDensity: 0.6,
  },
  {
    level: 6,
    name: 'Monsoon Mudslide',
    subtitle: 'Treacherous mud ruts, falling boulders, and undulating hills',
    region: 'Rainshadow Gulch · 1,850m',
    surface: 'mud',
    surfaceLabel: 'Slick Mud',
    gripMultiplier: 0.76,
    lengthMeters: 1620,
    roadWidth: 9.4,
    curveAmplitude: 66,
    curveFrequency: 7.4,
    hairpinCount: 6,
    elevationGain: 66,
    hillFrequency: 6.5,
    obstacleCount: 40,
    dynamicHazardRatio: 0.42,
    parTimeSeconds: 78,
    skyTopColor: 0x0f171e,
    skyHorizonColor: 0x2b363e,
    terrainColor: 0x26291e,
    rockColor: 0x3f3f46,
    roadTint: 0x332920,
    sunIntensity: 1.35,
    guardrailDensity: 0.52,
  },
  {
    level: 7,
    name: 'Razorback Spur',
    subtitle: 'Exposed ridgeline where one wide drift drops off the cliff',
    region: 'Knife Ridge · 2,140m',
    surface: 'asphalt',
    surfaceLabel: 'Weathered Asphalt',
    gripMultiplier: 0.9,
    lengthMeters: 1750,
    roadWidth: 9.0,
    curveAmplitude: 74,
    curveFrequency: 8.2,
    hairpinCount: 7,
    elevationGain: 74,
    hillFrequency: 7.0,
    obstacleCount: 44,
    dynamicHazardRatio: 0.45,
    parTimeSeconds: 83,
    skyTopColor: 0x0d1b2a,
    skyHorizonColor: 0x415a77,
    terrainColor: 0x232d28,
    rockColor: 0x525b66,
    roadTint: 0x24272d,
    sunIntensity: 2.1,
    guardrailDensity: 0.42,
  },
  {
    level: 8,
    name: 'Copperhead Corkscrew',
    subtitle: 'Relentless rhythmic S-curves and heavy log hazards',
    region: 'Copper Basin · 2,380m',
    surface: 'gravel',
    surfaceLabel: 'Shale Gravel',
    gripMultiplier: 0.82,
    lengthMeters: 1880,
    roadWidth: 8.8,
    curveAmplitude: 80,
    curveFrequency: 9.0,
    hairpinCount: 8,
    elevationGain: 80,
    hillFrequency: 7.8,
    obstacleCount: 49,
    dynamicHazardRatio: 0.48,
    parTimeSeconds: 89,
    skyTopColor: 0x1e1824,
    skyHorizonColor: 0x6e4a3a,
    terrainColor: 0x382c23,
    rockColor: 0x634f40,
    roadTint: 0x332b25,
    sunIntensity: 1.85,
    guardrailDensity: 0.4,
  },
  {
    level: 9,
    name: 'Glacier Toe Approach',
    subtitle: 'Sub-zero frost patches mixed with rock chicanes',
    region: 'Snowline Pass · 2,660m',
    surface: 'ice',
    surfaceLabel: 'Frosted Tarmac',
    gripMultiplier: 0.74,
    lengthMeters: 2000,
    roadWidth: 8.6,
    curveAmplitude: 86,
    curveFrequency: 9.6,
    hairpinCount: 9,
    elevationGain: 86,
    hillFrequency: 8.2,
    obstacleCount: 53,
    dynamicHazardRatio: 0.5,
    parTimeSeconds: 95,
    skyTopColor: 0x0b192c,
    skyHorizonColor: 0x46698c,
    terrainColor: 0x3a4754,
    rockColor: 0x64748b,
    roadTint: 0x2a3340,
    sunIntensity: 2.25,
    guardrailDensity: 0.36,
  },
  {
    level: 10,
    name: 'Widowmaker Chicanes',
    subtitle: 'Narrow stone portals and active boulder avalanches',
    region: 'Granite Wall · 2,910m',
    surface: 'wet_asphalt',
    surfaceLabel: 'Cold Wet Asphalt',
    gripMultiplier: 0.79,
    lengthMeters: 2120,
    roadWidth: 8.4,
    curveAmplitude: 92,
    curveFrequency: 10.4,
    hairpinCount: 10,
    elevationGain: 92,
    hillFrequency: 8.8,
    obstacleCount: 58,
    dynamicHazardRatio: 0.54,
    parTimeSeconds: 100,
    skyTopColor: 0x090d16,
    skyHorizonColor: 0x28354a,
    terrainColor: 0x222933,
    rockColor: 0x475569,
    roadTint: 0x1e232b,
    sunIntensity: 1.45,
    guardrailDensity: 0.32,
  },
  {
    level: 11,
    name: 'Thunderhead Descent',
    subtitle: 'Steep downhill braking zones into blind hairpin traps',
    region: 'Storm Crest · 3,150m',
    surface: 'mud',
    surfaceLabel: 'Storm Mud & Shale',
    gripMultiplier: 0.73,
    lengthMeters: 2250,
    roadWidth: 8.3,
    curveAmplitude: 98,
    curveFrequency: 11.2,
    hairpinCount: 11,
    elevationGain: 98,
    hillFrequency: 9.5,
    obstacleCount: 63,
    dynamicHazardRatio: 0.58,
    parTimeSeconds: 106,
    skyTopColor: 0x070a12,
    skyHorizonColor: 0x1e293b,
    terrainColor: 0x1c211d,
    rockColor: 0x334155,
    roadTint: 0x26211d,
    sunIntensity: 1.25,
    guardrailDensity: 0.28,
  },
  {
    level: 12,
    name: 'Frostbite Switchbacks',
    subtitle: 'High-altitude black ice where counter-steering is survival',
    region: 'Glacial Shelf · 3,420m',
    surface: 'ice',
    surfaceLabel: 'Black Ice',
    gripMultiplier: 0.69,
    lengthMeters: 2380,
    roadWidth: 8.1,
    curveAmplitude: 105,
    curveFrequency: 12.0,
    hairpinCount: 12,
    elevationGain: 105,
    hillFrequency: 10.0,
    obstacleCount: 68,
    dynamicHazardRatio: 0.62,
    parTimeSeconds: 112,
    skyTopColor: 0x0c1829,
    skyHorizonColor: 0x38597a,
    terrainColor: 0x475569,
    rockColor: 0x64748b,
    roadTint: 0x283546,
    sunIntensity: 2.15,
    guardrailDensity: 0.25,
  },
  {
    level: 13,
    name: 'Volcanic Scree Run',
    subtitle: 'Ash-slick basalt ledge with dense falling rock barrages',
    region: 'Caldera Rim · 3,680m',
    surface: 'gravel',
    surfaceLabel: 'Volcanic Scree',
    gripMultiplier: 0.75,
    lengthMeters: 2500,
    roadWidth: 8.0,
    curveAmplitude: 112,
    curveFrequency: 12.8,
    hairpinCount: 13,
    elevationGain: 112,
    hillFrequency: 10.8,
    obstacleCount: 74,
    dynamicHazardRatio: 0.66,
    parTimeSeconds: 118,
    skyTopColor: 0x1a0f12,
    skyHorizonColor: 0x59251e,
    terrainColor: 0x261e1e,
    rockColor: 0x3f3434,
    roadTint: 0x211c1c,
    sunIntensity: 1.7,
    guardrailDensity: 0.2,
  },
  {
    level: 14,
    name: 'Nightfall Precipice',
    subtitle: 'Twilight cliffside dash relying on rally lamp beams',
    region: 'Abyssal Ledge · 3,950m',
    surface: 'wet_asphalt',
    surfaceLabel: 'Night Frost Tarmac',
    gripMultiplier: 0.74,
    lengthMeters: 2650,
    roadWidth: 7.9,
    curveAmplitude: 118,
    curveFrequency: 13.6,
    hairpinCount: 14,
    elevationGain: 120,
    hillFrequency: 11.5,
    obstacleCount: 80,
    dynamicHazardRatio: 0.7,
    parTimeSeconds: 124,
    skyTopColor: 0x04070d,
    skyHorizonColor: 0x131d31,
    terrainColor: 0x131921,
    rockColor: 0x293241,
    roadTint: 0x171b22,
    sunIntensity: 0.95,
    guardrailDensity: 0.16,
  },
  {
    level: 15,
    name: 'Devil’s Crown Summit',
    subtitle: 'The ultimate 4,300m gauntlet of hairpins, ice, and rockfalls',
    region: 'Apex Summit · 4,300m',
    surface: 'ice',
    surfaceLabel: 'Summit Ice & Shale',
    gripMultiplier: 0.67,
    lengthMeters: 2850,
    roadWidth: 7.7,
    curveAmplitude: 126,
    curveFrequency: 14.8,
    hairpinCount: 16,
    elevationGain: 132,
    hillFrequency: 12.5,
    obstacleCount: 88,
    dynamicHazardRatio: 0.75,
    parTimeSeconds: 134,
    skyTopColor: 0x090b14,
    skyHorizonColor: 0x3b2d54,
    terrainColor: 0x2c3545,
    rockColor: 0x4c566a,
    roadTint: 0x222834,
    sunIntensity: 1.8,
    guardrailDensity: 0.12,
  },
];

/** Deterministic seeded PRNG for reproducible obstacle & road layouts per level */
export function createSeededRandom(seed: number): () => number {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/** Generate obstacles ("samne badha") for a given level config */
export function generateLevelObstacles(cfg: LevelConfig): ObstacleInstance[] {
  const rand = createSeededRandom(cfg.level * 9137 + 42);
  const obstacles: ObstacleInstance[] = [];
  const count = cfg.obstacleCount;

  const startSafeT = 0.045;
  const endSafeT = 0.965;
  const spanT = endSafeT - startSafeT;

  for (let i = 0; i < count; i++) {
    const baseT = startSafeT + (i / count) * spanT;
    const jitter = ((rand() - 0.5) * spanT) / (count * 1.4);
    const t = Math.max(startSafeT, Math.min(endSafeT, baseT + jitter));

    const rType = rand();
    let type: ObstacleType = 'boulder';
    if (rType < cfg.dynamicHazardRatio * 0.55) {
      type = 'rockfall';
    } else if (rType < cfg.dynamicHazardRatio) {
      type = 'rolling_log';
    } else if (rType < cfg.dynamicHazardRatio + 0.22) {
      type = 'barrier';
    } else if (rType < cfg.dynamicHazardRatio + 0.36) {
      type = 'narrow_gate';
    } else if (rType < cfg.dynamicHazardRatio + 0.52) {
      type = 'oil_slick';
    } else {
      type = 'boulder';
    }

    // Ensure players always have a threadable gap even in dense sections
    let lateralRatio = (rand() - 0.5) * 1.35;
    if (type === 'narrow_gate') {
      // Narrow gate leaves a central or slightly offset passage
      lateralRatio = (rand() - 0.5) * 0.45;
    } else if (type === 'barrier') {
      // Barriers hug left or right lane
      lateralRatio = (rand() > 0.5 ? 1 : -1) * (0.32 + rand() * 0.35);
    }

    const radius =
      type === 'boulder'
        ? 1.15 + rand() * 0.55
        : type === 'rockfall'
          ? 1.2 + rand() * 0.45
          : type === 'rolling_log'
            ? 1.45
            : type === 'barrier'
              ? 1.55
              : type === 'narrow_gate'
                ? 1.75
                : 1.9; // oil_slick

    const speed =
      type === 'rolling_log'
        ? 1.4 + rand() * 1.4 + cfg.level * 0.08
        : type === 'rockfall'
          ? 1.6 + rand() * 1.5 + cfg.level * 0.1
          : 0;

    obstacles.push({
      id: i + 1,
      type,
      t,
      lateralRatio,
      radius,
      speed,
      phase: rand() * Math.PI * 2,
    });
  }

  return obstacles;
}
