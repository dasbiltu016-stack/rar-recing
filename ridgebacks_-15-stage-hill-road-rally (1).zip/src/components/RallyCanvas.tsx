import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  LEVELS,
  LevelConfig,
  generateLevelObstacles,
} from '../game/levels';
import {
  BuiltTrack,
  CarRig,
  buildHillRoadTrack,
  createRallyCarModel,
} from '../game/models';
import { rallyAudio } from '../game/audio';

export type GamePhase = 'title' | 'playing' | 'paused' | 'victory' | 'gameover';
export type CameraMode = 'chase' | 'action' | 'hood';

export interface TelemetryData {
  speedKmh: number;
  rpm: number;
  gear: number;
  progressPct: number;
  distanceMeters: number;
  totalMeters: number;
  elapsedSeconds: number;
  hullHealth: number;
  fuel: number;
  nitroCharge: number;
  slopePercent: number;
  gripPercent: number;
  paceNote: string;
  paceSeverity: 'normal' | 'caution' | 'danger';
  hitFlash: boolean;
  driftActive: boolean;
}

export interface TouchInputState {
  steer: number; // -1 to 1
  throttle: boolean;
  brake: boolean;
  handbrake: boolean;
  nitro: boolean;
}

interface RallyCanvasProps {
  levelIndex: number; // 0 to 14
  gamePhase: GamePhase;
  cameraMode: CameraMode;
  liveryHex: number;
  resetCounter: number;
  refillCounter: number;
  touchInputRef: React.MutableRefObject<{
    steer: number;
    throttle: boolean;
    brake: boolean;
    handbrake: boolean;
    nitro: boolean;
  }>;
  onTelemetry: (data: TelemetryData) => void;
  onStageComplete: (stats: {
    timeSeconds: number;
    hullRemaining: number;
    collisions: number;
    stars: number;
  }) => void;
  onGameOver: (reason: string) => void;
  onTogglePause: () => void;
  onStartFromKey: () => void;
  onCycleCamera: () => void;
  onToggleDock: () => void;
}

// Reusable module-scope math objects (Zero GC in render loop)
const _pt = new THREE.Vector3();
const _ptAhead = new THREE.Vector3();
const _ptFar = new THREE.Vector3();
const _tan = new THREE.Vector3();
const _tanAhead = new THREE.Vector3();
const _right = new THREE.Vector3();
const _normal = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _carWorldPos = new THREE.Vector3();
const _camTargetPos = new THREE.Vector3();
const _camLookAt = new THREE.Vector3();
const _obsWorldPos = new THREE.Vector3();
const _crossVec = new THREE.Vector3();
const _rotMatrix = new THREE.Matrix4();
const _targetQuat = new THREE.Quaternion();
const _yawQuat = new THREE.Quaternion();
const _dummyObj = new THREE.Object3D();

const PARTICLE_COUNT = 48;

export const RallyCanvas: React.FC<RallyCanvasProps> = ({
  levelIndex,
  gamePhase,
  cameraMode,
  liveryHex,
  resetCounter,
  refillCounter,
  touchInputRef,
  onTelemetry,
  onStageComplete,
  onGameOver,
  onTogglePause,
  onStartFromKey,
  onCycleCamera,
  onToggleDock,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // Latest props in refs so the game loop never tears down the WebGL context
  const phaseRef = useRef<GamePhase>(gamePhase);
  const cameraModeRef = useRef<CameraMode>(cameraMode);
  const levelIndexRef = useRef<number>(levelIndex);
  const callbacksRef = useRef({
    onTelemetry,
    onStageComplete,
    onGameOver,
    onTogglePause,
    onStartFromKey,
    onCycleCamera,
    onToggleDock,
  });

  useEffect(() => {
    phaseRef.current = gamePhase;
  }, [gamePhase]);

  useEffect(() => {
    cameraModeRef.current = cameraMode;
  }, [cameraMode]);

  useEffect(() => {
    callbacksRef.current = {
      onTelemetry,
      onStageComplete,
      onGameOver,
      onTogglePause,
      onStartFromKey,
      onCycleCamera,
      onToggleDock,
    };
  });

  // Expose scene rebuild trigger, livery updater, and reward refill via ref
  const engineStateRef = useRef<{
    loadLevel: (idx: number) => void;
    setLivery: (hex: number) => void;
    refillAll: () => void;
  } | null>(null);

  useEffect(() => {
    levelIndexRef.current = levelIndex;
    engineStateRef.current?.loadLevel(levelIndex);
  }, [levelIndex, resetCounter]);

  useEffect(() => {
    if (refillCounter > 0) {
      engineStateRef.current?.refillAll();
    }
  }, [refillCounter]);

  useEffect(() => {
    engineStateRef.current?.setLivery(liveryHex);
  }, [liveryHex]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Software WebGL detection
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      62,
      container.clientWidth / Math.max(1, container.clientHeight),
      0.2,
      550
    );

    // 2. Mandatory Studio Environment Reflection (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    pmremGenerator.dispose();

    // 3. Balanced 3-Point Mountain Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.9);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffbeb, 2.1);
    sunLight.position.set(35, 65, 25);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 5;
    sunLight.shadow.camera.far = 160;
    const d = 32;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.02;
    scene.add(sunLight);
    scene.add(sunLight.target);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.65);
    rimLight.position.set(-30, 25, -40);
    scene.add(rimLight);

    // 4. Create Composite 11-Part Rally Car
    const carRig: CarRig = createRallyCarModel(liveryHex);
    scene.add(carRig.root);

    // 5. Pooled Particle System (Gravel dust, tire smoke, impact sparks)
    const particleGeo = new THREE.DodecahedronGeometry(0.18, 0);
    const particleMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      transparent: true,
      opacity: 0.85,
    });
    const particleMesh = new THREE.InstancedMesh(
      particleGeo,
      particleMat,
      PARTICLE_COUNT
    );
    particleMesh.instanceColor = new THREE.InstancedBufferAttribute(
      new Float32Array(PARTICLE_COUNT * 3),
      3
    );
    particleMesh.frustumCulled = false;
    scene.add(particleMesh);

    interface ParticleItem {
      active: boolean;
      pos: THREE.Vector3;
      vel: THREE.Vector3;
      life: number;
      maxLife: number;
      scale: number;
      color: THREE.Color;
    }
    const particles: ParticleItem[] = Array.from(
      { length: PARTICLE_COUNT },
      () => ({
        active: false,
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.5,
        scale: 1,
        color: new THREE.Color(0xfbbf24),
      })
    );

    const spawnParticles = (
      origin: THREE.Vector3,
      count: number,
      colorHex: number,
      speedSpread: number,
      upBoost: number,
      scaleBase: number
    ) => {
      let spawned = 0;
      for (let i = 0; i < PARTICLE_COUNT && spawned < count; i++) {
        const p = particles[i];
        if (!p.active) {
          p.active = true;
          p.pos.copy(origin);
          p.vel.set(
            (Math.random() - 0.5) * speedSpread,
            upBoost + Math.random() * speedSpread * 0.5,
            (Math.random() - 0.5) * speedSpread
          );
          p.life = 0;
          p.maxLife = 0.28 + Math.random() * 0.28;
          p.scale = scaleBase * (0.7 + Math.random() * 0.6);
          p.color.setHex(colorHex);
          spawned++;
        }
      }
    };

    // 6. Vehicle Physics & Track State
    let currentCfg: LevelConfig = LEVELS[levelIndexRef.current] || LEVELS[0];
    let builtTrack: BuiltTrack | null = null;

    const sim = {
      t: 0.008, // Normalized spline progress (0..1)
      speed: 0, // m/s forward speed
      lateralOffset: 0, // meters from road centerline
      lateralVel: 0, // m/s lateral velocity
      yawOffset: 0, // radians relative to road tangent
      yawRate: 0,
      steerAngle: 0,
      hullHealth: 100,
      fuel: 100,
      nitroCharge: 100,
      elapsedSeconds: 0,
      collisions: 0,
      hitstopTimer: 0,
      hitFlashTimer: 0,
      shakeTrauma: 0,
      stageFinished: false,
      titleOrbitAngle: 0,
      smoothedCamPos: new THREE.Vector3(0, 6, 12),
      smoothedCamLook: new THREE.Vector3(0, 2, -10),
    };

    const loadLevel = (idx: number) => {
      const safeIdx = Math.max(0, Math.min(LEVELS.length - 1, idx));
      currentCfg = LEVELS[safeIdx];

      if (builtTrack) {
        scene.remove(builtTrack.trackGroup);
        builtTrack.dispose();
      }

      const obsDefs = generateLevelObstacles(currentCfg);
      builtTrack = buildHillRoadTrack(renderer, currentCfg, obsDefs);
      scene.add(builtTrack.trackGroup);

      // Update atmosphere & lighting for this stage
      scene.background = new THREE.Color(currentCfg.skyHorizonColor);
      scene.fog = new THREE.FogExp2(currentCfg.skyHorizonColor, 0.0028);
      hemiLight.color.setHex(currentCfg.skyTopColor).lerp(new THREE.Color(0xffffff), 0.65);
      hemiLight.groundColor.setHex(currentCfg.terrainColor);
      hemiLight.intensity = 1.35;
      sunLight.intensity = currentCfg.sunIntensity * 1.15;

      // Reset vehicle physics state at start line
      sim.t = 0.008;
      sim.speed = 0;
      sim.lateralOffset = 0;
      sim.lateralVel = 0;
      sim.yawOffset = 0;
      sim.yawRate = 0;
      sim.steerAngle = 0;
      sim.hullHealth = 100;
      sim.fuel = 100;
      sim.nitroCharge = 100;
      sim.elapsedSeconds = 0;
      sim.collisions = 0;
      sim.hitstopTimer = 0;
      sim.hitFlashTimer = 0;
      sim.shakeTrauma = 0;
      sim.stageFinished = false;

      // Snap car and camera to initial start pose
      builtTrack.curve.getPointAt(sim.t, _pt);
      builtTrack.curve.getTangentAt(sim.t, _tan).normalize();
      carRig.root.position.copy(_pt);
      carRig.root.rotation.set(0, Math.atan2(-_tan.x, -_tan.z), 0);

      sim.smoothedCamPos
        .copy(_pt)
        .addScaledVector(_tan, -8.5)
        .add(new THREE.Vector3(0, 4.2, 0));
      sim.smoothedCamLook.copy(_pt).addScaledVector(_tan, 12);

      if (!isSoftwareGl) {
        renderer.compile(scene, camera);
      }
    };

    const setLivery = (hex: number) => {
      carRig.paintMaterials.forEach((m) => m.color.setHex(hex));
    };

    const refillAll = () => {
      sim.hullHealth = 100;
      sim.fuel = 100;
      sim.nitroCharge = 100;
      sim.stageFinished = false;
      sim.lateralOffset = THREE.MathUtils.clamp(sim.lateralOffset, -1.5, 1.5);
      sim.lateralVel = 0;
      sim.yawOffset = 0;
      rallyAudio.playCheckpoint();
    };

    engineStateRef.current = { loadLevel, setLivery, refillAll };
    loadLevel(levelIndexRef.current);

    // 7. Responsive Keyboard Input Handling (Held vs Edge-Triggered)
    const heldKeys = new Set<string>();

    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      if (
        code === 'ArrowUp' ||
        code === 'ArrowDown' ||
        code === 'ArrowLeft' ||
        code === 'ArrowRight' ||
        code === 'Space'
      ) {
        e.preventDefault();
      }

      if (!heldKeys.has(code)) {
        // Edge-triggered actions
        if (code === 'Escape' || code === 'KeyP') {
          if (phaseRef.current === 'playing' || phaseRef.current === 'paused') {
            callbacksRef.current.onTogglePause();
          }
        } else if (code === 'Enter' || code === 'Space') {
          if (phaseRef.current === 'title') {
            rallyAudio.startEngineLoop();
            callbacksRef.current.onStartFromKey();
          }
        } else if (code === 'KeyC') {
          callbacksRef.current.onCycleCamera();
        } else if (code === 'KeyH') {
          callbacksRef.current.onToggleDock();
        } else if (code === 'ShiftLeft' || code === 'ShiftRight') {
          if (phaseRef.current === 'playing' && sim.nitroCharge > 15) {
            rallyAudio.playBoostBurst();
          }
        }
      }

      heldKeys.add(code);
      if (phaseRef.current === 'playing') {
        rallyAudio.startEngineLoop();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      heldKeys.delete(e.code);
    };

    const onWindowBlur = () => {
      heldKeys.clear();
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onWindowBlur);

    // 8. Resize Handler
    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = Math.max(1, container.clientHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    // 9. Main 60fps Simulation & Render Loop (with Software WebGL Pacing)
    let frameId = 0;
    let disposed = false;
    let lastTime = performance.now();
    let telemetryTimer = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const now = performance.now();
      const rawDt = (now - lastTime) * 0.001;
      lastTime = now;
      // Clamp frame delta time to prevent physics tunneling
      const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

      const phase = phaseRef.current;
      const track = builtTrack;

      if (track) {
        const halfWidth = currentCfg.roadWidth * 0.5;

        // Animate dynamic obstacles ("samne badha") in both title and playing states
        const animTime = now * 0.001;
        for (let i = 0; i < track.obstacles.length; i++) {
          const obs = track.obstacles[i];
          if (obs.hitCooldown > 0) {
            obs.hitCooldown = Math.max(0, obs.hitCooldown - dt);
          }

          if (obs.data.type === 'rolling_log') {
            const sweep =
              Math.sin(animTime * obs.data.speed + obs.data.phase) *
              (halfWidth - 1.65);
            obs.group.position
              .copy(obs.basePos)
              .addScaledVector(obs.right, sweep);
            obs.mesh.rotation.x = animTime * obs.data.speed * 2.2;
            if (obs.telegraphRing) {
              const s = 0.9 + Math.sin(animTime * 8) * 0.15;
              obs.telegraphRing.scale.setScalar(s);
            }
          } else if (obs.data.type === 'rockfall') {
            const sweep =
              Math.cos(animTime * obs.data.speed + obs.data.phase) *
              (halfWidth - 1.5);
            const bounce =
              Math.abs(
                Math.sin(animTime * obs.data.speed * 1.9 + obs.data.phase)
              ) * 1.85;
            obs.group.position
              .copy(obs.basePos)
              .addScaledVector(obs.right, sweep);
            obs.mesh.position.y = obs.data.radius * 0.78 + bounce;
            obs.mesh.rotation.z = animTime * 3.2;
            if (obs.telegraphRing) {
              const ringScale = Math.max(0.45, 1.35 - bounce * 0.45);
              obs.telegraphRing.scale.setScalar(ringScale);
            }
          }
        }

        if (phase === 'playing' && !sim.stageFinished) {
          // Brief hitstop on heavy collision
          if (sim.hitstopTimer > 0) {
            sim.hitstopTimer = Math.max(0, sim.hitstopTimer - dt);
          } else {
            sim.elapsedSeconds += dt;

            // Gather inputs (Keyboard + Touch)
            const tIn = touchInputRef.current;
            const throttleInput =
              heldKeys.has('KeyW') ||
              heldKeys.has('ArrowUp') ||
              tIn.throttle
                ? 1
                : 0;
            const brakeInput =
              heldKeys.has('KeyS') ||
              heldKeys.has('ArrowDown') ||
              tIn.brake
                ? 1
                : 0;
            const leftInput =
              heldKeys.has('KeyA') || heldKeys.has('ArrowLeft') ? 1 : 0;
            const rightInput =
              heldKeys.has('KeyD') || heldKeys.has('ArrowRight') ? 1 : 0;
            const handbrakeInput =
              heldKeys.has('Space') || tIn.handbrake;
            const nitroInput =
              (heldKeys.has('ShiftLeft') ||
                heldKeys.has('ShiftRight') ||
                tIn.nitro) &&
              sim.nitroCharge > 2;

            let rawSteer = rightInput - leftInput;
            if (Math.abs(tIn.steer) > 0.05) {
              rawSteer = tIn.steer;
            }

            // Evaluate current spline point, tangent, slope, and curvature
            track.curve.getPointAt(sim.t, _pt);
            track.curve.getTangentAt(sim.t, _tan).normalize();
            const lookDeltaT = Math.min(1, sim.t + 8 / currentCfg.lengthMeters);
            track.curve.getTangentAt(lookDeltaT, _tanAhead).normalize();

            // Signed horizontal curvature kCurve (+ = right turn, - = left turn)
            _crossVec.crossVectors(_tan, _tanAhead);
            const kCurve = (-_crossVec.y / 8.0) * 14.5;

            // Hill slope grade (+ = uphill climb, - = downhill plunge)
            const slopeGrade = _tan.y;

            // Surface grip & shoulder penalty
            const onShoulder = Math.abs(sim.lateralOffset) > halfWidth - 1.05;
            const effectiveGrip =
              currentCfg.gripMultiplier *
              (onShoulder ? 0.68 : 1.0) *
              (handbrakeInput ? 0.52 : 1.0);

            // Nitro boost consumption / recharge
            let boostAccel = 0;
            if (nitroInput && throttleInput > 0 && sim.fuel > 0) {
              sim.nitroCharge = Math.max(0, sim.nitroCharge - dt * 28);
              boostAccel = 16.5;
            } else {
              sim.nitroCharge = Math.min(100, sim.nitroCharge + dt * 7.5);
            }

            // Fuel consumption while engine is running / driving
            if (throttleInput > 0 || Math.abs(sim.speed) > 1.5) {
              const fuelBurnRate =
                0.75 +
                throttleInput * 1.45 +
                (nitroInput && throttleInput > 0 ? 1.6 : 0);
              sim.fuel = Math.max(0, sim.fuel - fuelBurnRate * dt);
            }

            // Longitudinal acceleration (hill slope pulls back on climbs and speeds up on descents!)
            const maxSpeed = 42 + currentCfg.level * 0.55 + (nitroInput ? 11 : 0);
            const engineForce =
              sim.fuel > 0 ? throttleInput * (24.5 + boostAccel) : 0;
            const brakeForce = brakeInput * 32.0 + (handbrakeInput ? 14.0 : 0);
            const gravitySlopeForce = -slopeGrade * 21.0;
            const rollingDrag =
              sim.speed * (onShoulder ? 0.85 : 0.26) +
              sim.speed * Math.abs(sim.speed) * 0.0065;

            if (sim.speed >= 0) {
              sim.speed +=
                (engineForce - brakeForce + gravitySlopeForce - rollingDrag) *
                dt;
              if (sim.speed < 0 && brakeInput > 0 && throttleInput === 0) {
                sim.speed = Math.max(-10, sim.speed);
              } else if (sim.speed < 0) {
                sim.speed = 0;
              }
            } else {
              // Reverse gear
              sim.speed += (throttleInput * 22 - brakeInput * 10 + 4.0) * dt;
              sim.speed = Math.max(-11, sim.speed);
            }
            sim.speed = Math.min(maxSpeed, sim.speed);

            // Steering & Challenging Cornering / Drift Dynamics
            const steerResponsiveness = handbrakeInput ? 9.5 : 7.2;
            sim.steerAngle = THREE.MathUtils.damp(
              sim.steerAngle,
              rawSteer,
              steerResponsiveness,
              dt
            );

            const speedFactor = Math.min(1.2, Math.abs(sim.speed) / 14);
            const turnRate =
              sim.steerAngle *
              (2.35 * effectiveGrip + (handbrakeInput ? 0.95 : 0)) *
              speedFactor;

            // Centrifugal force pushes car outward on sharp curves ("aka baka rasta")
            const centrifugalDrift =
              -kCurve * (sim.speed * sim.speed) * 0.029;

            sim.yawOffset = THREE.MathUtils.damp(
              sim.yawOffset,
              sim.steerAngle * (handbrakeInput ? 0.58 : 0.28) -
                kCurve * 0.22,
              5.5,
              dt
            );

            const lateralTargetVel =
              sim.speed * Math.sin(sim.yawOffset) +
              turnRate * 4.8 +
              centrifugalDrift;

            sim.lateralVel = THREE.MathUtils.damp(
              sim.lateralVel,
              lateralTargetVel,
              4.2 * effectiveGrip,
              dt
            );

            sim.lateralOffset += sim.lateralVel * dt;

            // Advance spline progress `t`
            const forwardSpeedAlongRoad =
              sim.speed * Math.cos(sim.yawOffset);
            sim.t += (forwardSpeedAlongRoad * dt) / currentCfg.lengthMeters;
            sim.t = Math.max(0.004, sim.t);

            // Inner Mountain Cliff Wall (Left boundary: -halfWidth - 0.35)
            const leftLimit = -(halfWidth - 0.45);
            if (sim.lateralOffset < leftLimit) {
              const impactVel = Math.abs(sim.lateralVel) + sim.speed * 0.22;
              sim.lateralOffset = leftLimit + 0.08;
              sim.lateralVel = Math.abs(sim.lateralVel) * 0.45 + 2.5;
              sim.speed *= 0.78;
              if (impactVel > 4.5 && sim.hitFlashTimer <= 0) {
                const dmg = Math.min(18, Math.round(impactVel * 0.85));
                sim.hullHealth = Math.max(0, sim.hullHealth - dmg);
                sim.collisions += 1;
                sim.shakeTrauma = Math.min(1, sim.shakeTrauma + 0.45);
                sim.hitFlashTimer = 0.22;
                rallyAudio.playImpact(0.75);
                spawnParticles(carRig.root.position, 10, 0xfbbf24, 9, 4, 1.1);
              }
            }

            // Outer Canyon Cliff Edge / Guardrail (Right boundary: +halfWidth)
            const rightGuardLimit = halfWidth - 0.35;
            if (sim.lateralOffset > rightGuardLimit) {
              // Check if guardrail catches the car or if the car plunges off the cliff
              const overEdgeDist = sim.lateralOffset - rightGuardLimit;
              if (overEdgeDist > 1.85) {
                // Plunged off the mountain cliff!
                sim.hullHealth = 0;
                rallyAudio.playGameOverTone();
                callbacksRef.current.onGameOver(
                  'Plunged off the exposed mountain cliff edge!'
                );
              } else {
                // Scrape / bounce off guardrail
                const impactVel = Math.abs(sim.lateralVel) + sim.speed * 0.2;
                sim.lateralOffset = rightGuardLimit - 0.06;
                sim.lateralVel = -Math.abs(sim.lateralVel) * 0.45 - 2.2;
                sim.speed *= 0.8;
                if (impactVel > 4.5 && sim.hitFlashTimer <= 0) {
                  const dmg = Math.min(16, Math.round(impactVel * 0.8));
                  sim.hullHealth = Math.max(0, sim.hullHealth - dmg);
                  sim.collisions += 1;
                  sim.shakeTrauma = Math.min(1, sim.shakeTrauma + 0.45);
                  sim.hitFlashTimer = 0.22;
                  rallyAudio.playImpact(0.75);
                  spawnParticles(carRig.root.position, 10, 0xf97316, 9, 4, 1.1);
                }
              }
            }

            // Compute updated 3D world position & orientation of the car
            track.curve.getPointAt(Math.min(0.995, sim.t), _pt);
            track.curve.getTangentAt(Math.min(0.995, sim.t), _tan).normalize();
            _right.crossVectors(_tan, _up).normalize();
            _normal.crossVectors(_right, _tan).normalize();

            _carWorldPos
              .copy(_pt)
              .addScaledVector(_right, sim.lateralOffset)
              .add(new THREE.Vector3(0, 0.02, 0));

            carRig.root.position.copy(_carWorldPos);

            // Align car with 3D road tangent + slope pitch + drift yaw
            _ptAhead.copy(_pt).add(_tan);
            _rotMatrix.lookAt(_pt, _ptAhead, _normal);
            _targetQuat.setFromRotationMatrix(_rotMatrix);
            _yawQuat.setFromAxisAngle(_up, -sim.yawOffset);
            _targetQuat.multiply(_yawQuat);
            carRig.root.quaternion.slerp(_targetQuat, Math.min(1, dt * 16));

            // Suspension roll & pitch visual feedback on car bodyGroup
            const targetRoll = THREE.MathUtils.clamp(
              -sim.steerAngle * (sim.speed / 35) * 0.14,
              -0.16,
              0.16
            );
            const targetPitch = THREE.MathUtils.clamp(
              (brakeInput * 0.07 - throttleInput * 0.05) * (sim.speed / 25),
              -0.09,
              0.09
            );
            carRig.bodyGroup.rotation.z = THREE.MathUtils.damp(
              carRig.bodyGroup.rotation.z,
              targetRoll,
              10,
              dt
            );
            carRig.bodyGroup.rotation.x = THREE.MathUtils.damp(
              carRig.bodyGroup.rotation.x,
              targetPitch,
              10,
              dt
            );

            // Spin wheels & steer front wheel pivots
            carRig.wheelFrontLeftPivot.rotation.y = -sim.steerAngle * 0.48;
            carRig.wheelFrontRightPivot.rotation.y = -sim.steerAngle * 0.48;
            const wheelSpinDelta = -(sim.speed * dt) / 0.42;
            for (let w = 0; w < carRig.wheels.length; w++) {
              carRig.wheels[w].rotation.x += wheelSpinDelta;
            }

            // Brake light glow & Nitro exhaust flames
            carRig.brakeLights.emissiveIntensity =
              brakeInput > 0 || handbrakeInput ? 2.8 : 0.7;
            const showFlames = nitroInput && throttleInput > 0;
            for (let f = 0; f < carRig.nitroFlames.length; f++) {
              carRig.nitroFlames[f].visible = showFlames;
              if (showFlames) {
                carRig.nitroFlames[f].scale.setScalar(
                  0.85 + Math.random() * 0.4
                );
              }
            }

            // Spawn tire drift / gravel dust particles
            const driftIntensity = Math.min(
              1,
              Math.abs(sim.lateralVel) / 8.5 +
                (handbrakeInput && sim.speed > 8 ? 0.65 : 0) +
                (onShoulder && sim.speed > 10 ? 0.4 : 0)
            );
            if (driftIntensity > 0.28 && sim.speed > 6) {
              spawnParticles(
                _carWorldPos.clone().addScaledVector(_tan, -1.8),
                1,
                currentCfg.surface === 'ice' ? 0xe2e8f0 : 0xd6d3d1,
                3.5,
                1.4,
                0.85
              );
            }

            // Update procedural audio telemetry
            rallyAudio.updateTelemetry(
              sim.speed / 38,
              throttleInput,
              driftIntensity,
              showFlames,
              true
            );

            // Check collisions against Obstacles ("samne badha")
            for (let i = 0; i < track.obstacles.length; i++) {
              const obs = track.obstacles[i];
              // Fast spline T filter first
              if (
                Math.abs(obs.data.t - sim.t) * currentCfg.lengthMeters > 9.0 ||
                obs.hitCooldown > 0
              ) {
                continue;
              }

              _obsWorldPos.copy(obs.group.position);

              if (obs.data.type === 'narrow_gate') {
                // Narrow gate has two rock pillars at ±2.6m in local gate X
                const relVec = _carWorldPos.clone().sub(_obsWorldPos);
                const localX = relVec.dot(obs.right);
                const localZ = relVec.dot(obs.tangent);
                if (
                  Math.abs(localZ) < 1.85 &&
                  (Math.abs(localX - 2.6) < 1.65 ||
                    Math.abs(localX + 2.6) < 1.65)
                ) {
                  obs.hitCooldown = 0.85;
                  sim.speed *= 0.35;
                  sim.hullHealth = Math.max(0, sim.hullHealth - 22);
                  sim.collisions += 1;
                  sim.hitstopTimer = 0.055;
                  sim.hitFlashTimer = 0.28;
                  sim.shakeTrauma = Math.min(1, sim.shakeTrauma + 0.75);
                  rallyAudio.playImpact(1.15);
                  spawnParticles(_carWorldPos, 16, 0xf97316, 12, 5, 1.3);
                }
              } else {
                const dist = _carWorldPos.distanceTo(_obsWorldPos);
                const hitRadius = obs.data.radius + 1.05;
                if (dist < hitRadius) {
                  obs.hitCooldown = 0.85;
                  if (obs.data.type === 'oil_slick') {
                    // Oil slick induces sudden yaw spin and slip!
                    sim.yawOffset += (Math.random() > 0.5 ? 1 : -1) * 0.46;
                    sim.lateralVel += (Math.random() - 0.5) * 11;
                    sim.shakeTrauma = Math.min(1, sim.shakeTrauma + 0.25);
                    rallyAudio.playImpact(0.45);
                  } else {
                    // Solid boulder, barrier, rolling log, or rockfall collision
                    const dmg =
                      obs.data.type === 'rockfall' ||
                      obs.data.type === 'boulder'
                        ? 24
                        : 19;
                    sim.speed = Math.max(3, sim.speed * 0.32);
                    sim.lateralVel +=
                      (_carWorldPos.x > _obsWorldPos.x ? 1 : -1) * 6.5;
                    sim.hullHealth = Math.max(0, sim.hullHealth - dmg);
                    sim.collisions += 1;
                    sim.hitstopTimer = 0.055;
                    sim.hitFlashTimer = 0.3;
                    sim.shakeTrauma = Math.min(1, sim.shakeTrauma + 0.8);
                    rallyAudio.playImpact(1.2);
                    spawnParticles(_carWorldPos, 18, 0xef4444, 13, 5.5, 1.35);
                  }
                }
              }
            }

            // Check Hull Destruction or Fuel Depletion
            if (sim.hullHealth <= 0 && !sim.stageFinished) {
              sim.stageFinished = true;
              rallyAudio.updateTelemetry(0, 0, 0, false, false);
              rallyAudio.playGameOverTone();
              callbacksRef.current.onGameOver(
                'Chassis Hull reached 0%! Watch a Reward Test Ad to repair Hull & Fuel to 100%.'
              );
            } else if (sim.fuel <= 0 && sim.speed < 2.5 && !sim.stageFinished) {
              sim.stageFinished = true;
              rallyAudio.updateTelemetry(0, 0, 0, false, false);
              rallyAudio.playGameOverTone();
              callbacksRef.current.onGameOver(
                'Out of Fuel / Hull! Watch a Reward Test Ad to refill 100% and continue.'
              );
            }

            // Check Finish Archway Victory (t >= 0.985)
            if (sim.t >= 0.985 && !sim.stageFinished) {
              sim.stageFinished = true;
              rallyAudio.updateTelemetry(0, 0, 0, false, false);
              rallyAudio.playVictoryFanfare();
              const stars =
                sim.elapsedSeconds <= currentCfg.parTimeSeconds &&
                sim.hullHealth >= 60
                  ? 3
                  : sim.elapsedSeconds <= currentCfg.parTimeSeconds * 1.25
                    ? 2
                    : 1;
              callbacksRef.current.onStageComplete({
                timeSeconds: sim.elapsedSeconds,
                hullRemaining: Math.round(sim.hullHealth),
                collisions: sim.collisions,
                stars,
              });
            }
          }
        } else {
          // Pause or Title or Modal state: silence engine loop
          rallyAudio.updateTelemetry(0, 0, 0, false, false);
        }

        // Decay hit flash & camera shake trauma
        if (sim.hitFlashTimer > 0) {
          sim.hitFlashTimer = Math.max(0, sim.hitFlashTimer - dt);
        }
        if (sim.shakeTrauma > 0) {
          sim.shakeTrauma = Math.max(0, sim.shakeTrauma - dt * 1.85);
        }

        // 10. Camera Choreography (Title Screen Hero Orbit vs Chase / Action / Hood Cam)
        track.curve.getPointAt(Math.min(0.995, sim.t), _pt);
        track.curve.getTangentAt(Math.min(0.995, sim.t), _tan).normalize();
        _right.crossVectors(_tan, _up).normalize();

        if (phase === 'title') {
          sim.titleOrbitAngle += dt * 0.32;
          const orbitRadius = 8.2;
          const camX =
            carRig.root.position.x +
            Math.sin(sim.titleOrbitAngle) * orbitRadius;
          const camZ =
            carRig.root.position.z +
            Math.cos(sim.titleOrbitAngle) * orbitRadius;
          const camY = carRig.root.position.y + 3.1 + Math.sin(sim.titleOrbitAngle * 0.5) * 0.6;

          camera.position.set(camX, camY, camZ);
          camera.lookAt(
            carRig.root.position.x,
            carRig.root.position.y + 1.0,
            carRig.root.position.z - 1.5
          );
        } else {
          const mode = cameraModeRef.current;
          const isPortrait = camera.aspect < 1.0;
          if (mode === 'hood') {
            _camTargetPos
              .copy(carRig.root.position)
              .addScaledVector(_tan, 0.35)
              .add(new THREE.Vector3(0, 1.52, 0));
            _camLookAt
              .copy(carRig.root.position)
              .addScaledVector(_tan, 24.0)
              .add(new THREE.Vector3(0, 1.1, 0));
            sim.smoothedCamPos.lerp(_camTargetPos, Math.min(1, dt * 22));
            sim.smoothedCamLook.lerp(_camLookAt, Math.min(1, dt * 22));
          } else {
            const backDist =
              mode === 'action'
                ? isPortrait
                  ? 7.2
                  : 5.8
                : isPortrait
                  ? 10.2
                  : 8.4;
            const upHeight =
              mode === 'action'
                ? isPortrait
                  ? 3.8
                  : 2.65
                : isPortrait
                  ? 5.35
                  : 4.15;
            _camTargetPos
              .copy(carRig.root.position)
              .addScaledVector(_tan, -backDist)
              .addScaledVector(_right, sim.lateralVel * 0.08)
              .add(new THREE.Vector3(0, upHeight, 0));

            _camLookAt
              .copy(carRig.root.position)
              .addScaledVector(_tan, isPortrait ? 15.5 : 13.0)
              .add(new THREE.Vector3(0, isPortrait ? 0.65 : 1.1, 0));

            sim.smoothedCamPos.lerp(_camTargetPos, Math.min(1, dt * 10.5));
            sim.smoothedCamLook.lerp(_camLookAt, Math.min(1, dt * 12.5));
          }

          camera.position.copy(sim.smoothedCamPos);
          if (sim.shakeTrauma > 0.01) {
            const shakeMag = sim.shakeTrauma * sim.shakeTrauma * 0.55;
            camera.position.x += (Math.random() - 0.5) * shakeMag;
            camera.position.y += (Math.random() - 0.5) * shakeMag;
          }
          camera.lookAt(sim.smoothedCamLook);

          // Speed-scaled FOV sensation (wider on portrait screens so road edges stay visible)
          const baseFov = isPortrait
            ? cameraModeRef.current === 'action'
              ? 78
              : 72
            : cameraModeRef.current === 'action'
              ? 68
              : 60;
          const targetFov = baseFov + Math.min(14, (sim.speed / 45) * 12);
          camera.fov = THREE.MathUtils.damp(camera.fov, targetFov, 6, dt);
          camera.updateProjectionMatrix();
        }

        // Keep directional shadow camera centered on the car
        sunLight.position.set(
          carRig.root.position.x + 30,
          carRig.root.position.y + 55,
          carRig.root.position.z + 25
        );
        sunLight.target.position.copy(carRig.root.position);
        sunLight.target.updateMatrixWorld();

        // 11. Update Pooled 3D Particles
        for (let i = 0; i < PARTICLE_COUNT; i++) {
          const p = particles[i];
          if (p.active) {
            p.life += dt;
            if (p.life >= p.maxLife) {
              p.active = false;
              _dummyObj.scale.setScalar(0);
              _dummyObj.updateMatrix();
              particleMesh.setMatrixAt(i, _dummyObj.matrix);
            } else {
              p.vel.y -= 14.0 * dt;
              p.pos.addScaledVector(p.vel, dt);
              const lifeRatio = 1 - p.life / p.maxLife;
              _dummyObj.position.copy(p.pos);
              _dummyObj.scale.setScalar(p.scale * lifeRatio);
              _dummyObj.rotation.set(p.life * 4, p.life * 3, 0);
              _dummyObj.updateMatrix();
              particleMesh.setMatrixAt(i, _dummyObj.matrix);
              particleMesh.setColorAt(i, p.color);
            }
          } else {
            _dummyObj.scale.setScalar(0);
            _dummyObj.updateMatrix();
            particleMesh.setMatrixAt(i, _dummyObj.matrix);
          }
        }
        particleMesh.instanceMatrix.needsUpdate = true;
        if (particleMesh.instanceColor) {
          particleMesh.instanceColor.needsUpdate = true;
        }

        // 12. Emit HUD Telemetry (~15Hz to keep React HUD lightweight)
        telemetryTimer += dt;
        if (telemetryTimer >= 0.065) {
          telemetryTimer = 0;

          // Compute Co-Driver Pace Note looking 45m ahead
          const lookAheadT = Math.min(
            0.99,
            sim.t + 42 / currentCfg.lengthMeters
          );
          const lookFarT = Math.min(
            0.995,
            sim.t + 62 / currentCfg.lengthMeters
          );
          track.curve.getTangentAt(lookAheadT, _ptAhead).normalize();
          track.curve.getTangentAt(lookFarT, _ptFar).normalize();
          _crossVec.crossVectors(_ptAhead, _ptFar);
          const futureCurve = -_crossVec.y * 120;

          let paceNote = 'CLEAR CREST AHEAD';
          let paceSeverity: 'normal' | 'caution' | 'danger' = 'normal';

          // Check upcoming obstacle within 55m
          for (let i = 0; i < track.obstacles.length; i++) {
            const dMeters =
              (track.obstacles[i].data.t - sim.t) * currentCfg.lengthMeters;
            if (dMeters > 6 && dMeters < 52) {
              const oType = track.obstacles[i].data.type;
              if (oType === 'rockfall') {
                paceNote = 'FALLING BOULDERS AHEAD';
                paceSeverity = 'danger';
              } else if (oType === 'rolling_log') {
                paceNote = 'ROLLING TIMBER HAZARD';
                paceSeverity = 'danger';
              } else if (oType === 'narrow_gate') {
                paceNote = 'NARROW ROCK CHICANE';
                paceSeverity = 'caution';
              } else if (oType === 'oil_slick') {
                paceNote = 'SLICK SURFACE PATCH';
                paceSeverity = 'caution';
              } else {
                paceNote = 'OBSTACLE IN LANE';
                paceSeverity = 'caution';
              }
              break;
            }
          }

          if (paceSeverity === 'normal') {
            if (futureCurve > 4.2) {
              paceNote = 'HAIRPIN RIGHT';
              paceSeverity = 'danger';
            } else if (futureCurve < -4.2) {
              paceNote = 'HAIRPIN LEFT';
              paceSeverity = 'danger';
            } else if (futureCurve > 2.0) {
              paceNote = 'MEDIUM RIGHT TURN';
              paceSeverity = 'caution';
            } else if (futureCurve < -2.0) {
              paceNote = 'MEDIUM LEFT TURN';
              paceSeverity = 'caution';
            } else if (Math.abs(_tan.y) > 0.11) {
              paceNote =
                _tan.y > 0 ? 'STEEP HILL CLIMB' : 'STEEP DOWNHILL GRADE';
              paceSeverity = 'caution';
            }
          }

          const speedKmh = Math.round(Math.abs(sim.speed) * 3.6);
          const gear =
            speedKmh < 2
              ? 1
              : Math.min(6, Math.floor(speedKmh / 28) + 1);
          const rpm = Math.min(
            8500,
            Math.round(1400 + ((speedKmh % 28) / 28) * 5800 + speedKmh * 18)
          );

          callbacksRef.current.onTelemetry({
            speedKmh,
            rpm,
            gear,
            progressPct: Math.min(
              100,
              Math.max(0, Math.round(((sim.t - 0.008) / 0.977) * 100))
            ),
            distanceMeters: Math.min(
              currentCfg.lengthMeters,
              Math.round(sim.t * currentCfg.lengthMeters)
            ),
            totalMeters: currentCfg.lengthMeters,
            elapsedSeconds: sim.elapsedSeconds,
            hullHealth: Math.round(sim.hullHealth),
            fuel: Math.round(sim.fuel),
            nitroCharge: Math.round(sim.nitroCharge),
            slopePercent: Math.round(_tan.y * 100),
            gripPercent: Math.round(currentCfg.gripMultiplier * 100),
            paceNote,
            paceSeverity,
            hitFlash: sim.hitFlashTimer > 0,
            driftActive: Math.abs(sim.lateralVel) > 4.2,
          });
        }
      }

      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    }

    frameId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onWindowBlur);
      window.removeEventListener('resize', onResize);
      if (builtTrack) {
        builtTrack.dispose();
      }
      particleGeo.dispose();
      particleMat.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="absolute inset-0 w-full h-full overflow-hidden bg-[#090d14]"
    />
  );
};
